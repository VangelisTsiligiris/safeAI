# Design Guidelines: NFRS AI Toolkit

## Design Approach
**GOV.UK-Inspired Design System**: Following UK public sector design conventions with clear, accessible, and professional aesthetics. Prioritizing clarity, trust, and usability over decorative elements.

## Color System

### Primary Palette
- **NFRS Red** `#C8102E`: Primary actions, headers, key CTAs, navigation highlights
- **Dark Grey** `#2D2D2D`: Body text, headings, primary content
- **Light Grey** `#F5F5F5`: Page backgrounds, card backgrounds, section dividers
- **White** `#FFFFFF`: Card surfaces, input fields, modal overlays

### Functional Colors
- **Success Green** `#10B981`: "PERMITTED" compliance outcomes, success states, confirmation messages
- **Warning Amber** `#F59E0B`: "REFER BEFORE USE" outcomes, caution states, important notices
- **Prohibition Red** `#DC2626`: "PROHIBITED" outcomes, error states, critical warnings
- **Muted Grey** `#6B7280`: Secondary text, helper text, placeholder text

### Section-Specific Colors
- **Workshop Blue** `hsl(217 91% 38%)`: Workshop Learning Platform section identifier - icons, buttons, accents, borders (light mode)
- **Compliance Green** `hsl(142 76% 28%)`: AI Policy Compliance Checker section identifier - icons, buttons, accents, borders (light mode)
- Dark mode adjusts lightness values while maintaining WCAG 2.1 AA contrast (≥4.5:1)

These section colors create clear visual distinction between the two main toolkit modes, helping users immediately identify which section they're working in. All color combinations meet WCAG 2.1 AA accessibility requirements.

## Typography

### Font Stack
Primary: Inter or Open Sans (via Google Fonts CDN)
Fallback: system-ui, -apple-system, sans-serif

### Type Scale
- **H1**: 2.5rem (40px) / font-bold / leading-tight / text-gray-900
- **H2**: 2rem (32px) / font-bold / leading-tight / text-gray-900
- **H3**: 1.5rem (24px) / font-semibold / leading-snug / text-gray-800
- **H4**: 1.25rem (20px) / font-semibold / leading-snug / text-gray-800
- **Body**: 1rem (16px) / font-normal / leading-relaxed / text-gray-700
- **Small**: 0.875rem (14px) / font-normal / leading-normal / text-gray-600

## Layout System

### Spacing Primitives
Use Tailwind units: **4, 6, 8, 12, 16, 20, 24** for consistent vertical and horizontal rhythm.

### Container Widths
- **Full-width sections**: `w-full` with inner `max-w-7xl mx-auto px-6`
- **Content sections**: `max-w-5xl mx-auto`
- **Form containers**: `max-w-2xl mx-auto`
- **Cards/Panels**: Full width within containers with consistent `p-6` or `p-8`

### Grid Systems
- **Workshop scenarios**: `grid grid-cols-1 md:grid-cols-2 gap-6`
- **Department selection**: `grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4`
- **Assessment questions**: Single column with `space-y-6`

## Component Library

### Navigation
- **Header**: Fixed top, white background, NFRS red accent border-bottom (4px), logo left, navigation right
- **Mode Toggle**: Prominent pills/tabs for Workshop vs Compliance Checker switching
- **Breadcrumbs**: Grey text with red current page indicator

### Cards & Panels
- **Standard Card**: White background, rounded corners (8px), shadow-sm, border (1px light grey), padding 24px
- **Scenario Cards**: Elevated shadow-md, hover state with subtle scale, red left border accent (4px)
- **Decision Outcome Panels**: Border-left (8px) in outcome color (green/amber/red), matching light background tint

### Forms & Inputs
- **Text Input**: Border grey, rounded (6px), px-4 py-3, focus:border-red focus:ring-2 ring-red/20
- **Select Dropdown**: Matching input styling with chevron icon
- **Radio/Checkbox**: Custom styled with red accent when checked
- **Text Area**: Min-height 120px for discussion capture
- **Labels**: font-semibold, mb-2, text-gray-800

### Buttons
- **Primary CTA**: bg-nfrs-red, white text, px-6 py-3, rounded-lg, hover:brightness-110
- **Secondary**: border-2 border-grey, grey text, hover:bg-light-grey
- **Success Action**: bg-green, white text (for "Export PDF", "Complete Assessment")
- **Warning Action**: bg-amber, white text (for "Get Guidance")
- Touch targets: Minimum 44px height

### Status Indicators
- **PERMITTED Badge**: Green background, dark green text, border, icon (check-circle)
- **REFER Badge**: Amber background, dark amber text, border, icon (alert-triangle)
- **PROHIBITED Badge**: Red background, white text, border, icon (x-circle)

### Workshop Components
- **Timer Control**: Pill-shaped buttons for 5/10/15 min, countdown display in large digits, start/pause/reset controls
- **Progress Indicator**: Linear progress bar with red fill, showing module/scenario completion
- **Discussion Capture Box**: Light grey background, border-dashed, placeholder prompts in grey

### Compliance Checker Components
- **Question Card**: Numbered, clear yes/no/unsure options, helper text in muted grey
- **Decision Summary**: Large outcome badge at top, bulleted safeguards/referrals/prohibitions below
- **Contact Information Card**: Grey background, contact name, role, email, phone in structured layout

## Accessibility Requirements

### WCAG 2.1 AA Compliance
- Color contrast minimum 4.5:1 for normal text, 3:1 for large text
- All interactive elements keyboard accessible (tab order logical)
- Focus states: 2px offset outline in NFRS red
- Screen reader labels for all form inputs and icon buttons
- Skip to main content link
- Semantic HTML (nav, main, section, article)

### Touch & Interaction
- Minimum touch target: 44x44px
- Adequate spacing between clickable elements (8px minimum)
- Hover states for desktop, no hover-dependent functionality
- Loading states for async operations (spinner with red accent)

## Images

**No hero images required** - This is a functional, governmental tool focused on clarity and task completion, not marketing. 

**Iconography**: Use Lucide React icons throughout:
- Navigation: ChevronRight, Menu, X
- Actions: Download, Send, Save, Edit, Trash2
- Status: CheckCircle, AlertTriangle, XCircle, Info
- Functional: Clock, FileText, Users, Shield, Lock

**Logo Placement**: NFRS logo (vector or high-res PNG) in header, left-aligned, height 48px

## Page-Specific Guidelines

### Landing Page
Two-column card layout (Workshop / Compliance Checker), centered, max-width 1200px, icons above titles, red CTA buttons

### Workshop Flow
Sidebar navigation (desktop) showing modules, main content area with generous whitespace, scenario cards with expand/collapse, sticky action plan button

### Compliance Checker Flow
Step indicator at top (1/4, 2/4, etc.), single-column form progression, "Back" always available, final decision full-screen with clear export options

### PDF Exports
NFRS header with logo, document title in red, structured sections, timestamp footer, contact information panel, clean print-friendly layout

## Animation Principles
**Minimal and purposeful** - Avoid distracting animations. Use only:
- Fade-in for page transitions (200ms)
- Subtle hover lift on cards (transform: translateY(-2px))
- Smooth accordion expand/collapse (300ms ease)
- Timer countdown visual pulse