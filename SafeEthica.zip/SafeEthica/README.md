# NFRS AI Toolkit

A production-ready dual-mode web application for Nottinghamshire Fire & Rescue Service providing:

1. **Workshop Learning Platform**: Interactive educational experience for senior leadership training on AI governance, risks, and policy compliance aligned with POL 2114 (NFRS Artificial Intelligence Policy)

2. **AI Policy Compliance Checker**: Standalone assessment tool enabling all NFRS employees to evaluate whether their proposed AI tasks comply with organizational policy before implementation

3. **Admin-Managed Resources Library**: Secure file repository for training materials, policy documents, and other resources

## Features

- **Workshop Mode**: AI fundamentals, risk/ethics modules, interactive scenarios, and departmental action plan builder
- **Compliance Mode**: 12-question assessment aligned to POL 2114 with decision engine producing PERMITTED/REFER/PROHIBITED outcomes
- **Resources Section**: Public-facing library of admin-uploaded files
- **Admin Panel**: Secure file upload and management system with audit logging
- **User Authentication**: Replit Auth (OIDC) for secure access
- **PDF Export**: Generate compliance assessment reports
- **Responsive Design**: WCAG 2.1 AA accessible with NFRS branding

## Technology Stack

- **Frontend**: React + TypeScript, Vite, Tailwind CSS, shadcn/ui components
- **Backend**: Node.js, Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: OpenID Connect (OIDC) via Replit Auth
- **Session Management**: Express Session with PostgreSQL store

---

## Deployment Options

This application can be deployed in multiple environments. Choose the option that best fits your organization's infrastructure.

### Option 1: Replit Deployment (Easiest)

Replit provides the simplest deployment path with built-in authentication and database.

#### Prerequisites
- Replit account
- PostgreSQL database (provided by Replit)

#### Steps

1. **Fork or import this project to Replit**

2. **Configure secrets** (in Replit's Secrets tab):
   ```
   DATABASE_URL=<your_postgresql_connection_string>
   SESSION_SECRET=<generate_random_string>
   REPL_ID=<your_repl_id>
   ISSUER_URL=https://replit.com/oidc
   ```

3. **Set up the database**:
   ```bash
   npm run db:push
   ```

4. **Start the application**:
   ```bash
   npm run dev
   ```

5. **Access the application**: The app will be available at your Replit URL (e.g., `https://your-repl.your-username.repl.co`)

6. **Promote first admin user** (see Admin Access Setup section below)

### Option 2: Self-Hosted on Local Fire Service Server

Deploy on your own infrastructure with full control.

#### Prerequisites
- Ubuntu Server 20.04+ or similar Linux distribution
- Node.js 18+ and npm
- PostgreSQL 13+
- Nginx (recommended for reverse proxy)
- SSL/TLS certificate (Let's Encrypt recommended)

#### Step-by-Step Installation

##### 1. Install Dependencies

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 20 (LTS)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Nginx
sudo apt install -y nginx

# Install build tools (for native dependencies)
sudo apt install -y build-essential
```

##### 2. Set Up PostgreSQL Database

```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL shell:
CREATE DATABASE nfrs_ai_toolkit;
CREATE USER nfrs_app WITH ENCRYPTED PASSWORD 'your_secure_password_here';
GRANT ALL PRIVILEGES ON DATABASE nfrs_ai_toolkit TO nfrs_app;
\q
```

##### 3. Create Application User

```bash
# Create dedicated system user
sudo useradd -r -m -d /opt/nfrs-ai-toolkit -s /bin/bash nfrsapp

# Switch to application user
sudo su - nfrsapp
```

##### 4. Deploy Application Files

```bash
# Clone or copy application files to /opt/nfrs-ai-toolkit
cd /opt/nfrs-ai-toolkit

# If using git:
git clone <your-repository-url> .

# Or if transferring files:
# scp -r /path/to/nfrs-ai-toolkit/* nfrsapp@your-server:/opt/nfrs-ai-toolkit/

# Install dependencies
npm install

# Build the application
npm run build
```

##### 5. Configure Environment Variables

```bash
# Create environment file
nano /opt/nfrs-ai-toolkit/.env
```

Add the following (adjust values for your environment):

```env
NODE_ENV=production
PORT=5000

# Database Configuration
DATABASE_URL=postgresql://nfrs_app:your_secure_password_here@localhost:5432/nfrs_ai_toolkit

# Session Secret (generate with: openssl rand -base64 32)
SESSION_SECRET=your_generated_session_secret_here

# OIDC Configuration - SEE AUTHENTICATION SECTION BELOW
# For Replit Auth (if accessible):
REPL_ID=your_repl_id
ISSUER_URL=https://replit.com/oidc

# For other OIDC providers (Auth0, Keycloak, etc.):
# ISSUER_URL=https://your-auth-provider.com
# CLIENT_ID=your_client_id
# CLIENT_SECRET=your_client_secret
```

##### 6. Initialize Database Schema

```bash
# Run database migrations
npm run db:push
```

##### 7. Set Up Systemd Service

Exit the nfrsapp user and create a systemd service file:

```bash
exit  # Back to sudo user
sudo nano /etc/systemd/system/nfrs-ai-toolkit.service
```

Add the following content:

```ini
[Unit]
Description=NFRS AI Toolkit Web Application
After=network.target postgresql.service

[Service]
Type=simple
User=nfrsapp
WorkingDirectory=/opt/nfrs-ai-toolkit
EnvironmentFile=/opt/nfrs-ai-toolkit/.env
ExecStart=/usr/bin/npm start
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=nfrs-ai-toolkit

[Install]
WantedBy=multi-user.target
```

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable nfrs-ai-toolkit
sudo systemctl start nfrs-ai-toolkit

# Check status
sudo systemctl status nfrs-ai-toolkit
```

##### 8. Configure Nginx Reverse Proxy

```bash
sudo nano /etc/nginx/sites-available/nfrs-ai-toolkit
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name your-domain.fire-service.gov.uk;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.fire-service.gov.uk;

    # SSL Certificate Configuration
    ssl_certificate /etc/letsencrypt/live/your-domain.fire-service.gov.uk/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.fire-service.gov.uk/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # File Upload Size Limit
    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/nfrs-ai-toolkit /etc/nginx/sites-enabled/
sudo nginx -t  # Test configuration
sudo systemctl reload nginx
```

##### 9. Configure Firewall

```bash
# Allow SSH, HTTP, and HTTPS
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

##### 10. Set Up SSL Certificate (Let's Encrypt)

```bash
# Install certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.fire-service.gov.uk

# Test auto-renewal
sudo certbot renew --dry-run
```

---

### Option 3: Docker Deployment

Deploy using Docker containers for easier management.

#### Dockerfile

Create a `Dockerfile` in the project root:

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application files
COPY . .

# Build application
RUN npm run build

# Expose port
EXPOSE 5000

# Set environment
ENV NODE_ENV=production

# Start application
CMD ["npm", "start"]
```

#### docker-compose.yml

Create a `docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://nfrs_app:password@db:5432/nfrs_ai_toolkit
      - SESSION_SECRET=${SESSION_SECRET}
      - REPL_ID=${REPL_ID}
      - ISSUER_URL=${ISSUER_URL}
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=nfrs_ai_toolkit
      - POSTGRES_USER=nfrs_app
      - POSTGRES_PASSWORD=password
    restart: unless-stopped

volumes:
  postgres_data:
```

#### Deploy with Docker

```bash
# Build and start containers
docker-compose up -d

# Initialize database
docker-compose exec app npm run db:push

# View logs
docker-compose logs -f app
```

---

## Authentication Configuration

This application uses **OpenID Connect (OIDC)** for authentication. You have several options:

### Option A: Replit Auth (Default)

If deploying on Replit or with access to Replit's OIDC:

```env
REPL_ID=your_repl_id
ISSUER_URL=https://replit.com/oidc
```

### Option B: Auth0

1. Create an application in Auth0 dashboard
2. Configure environment variables:

```env
ISSUER_URL=https://your-tenant.auth0.com
REPL_ID=your_auth0_client_id
```

3. Set callback URL in Auth0: `https://your-domain.fire-service.gov.uk/api/callback`

### Option C: Keycloak (Self-Hosted)

1. Install and configure Keycloak
2. Create a realm and client
3. Configure environment variables:

```env
ISSUER_URL=https://your-keycloak.fire-service.gov.uk/realms/your-realm
REPL_ID=your_client_id
```

### Option D: Azure AD / Entra ID

1. Register an application in Azure Portal
2. Configure environment variables:

```env
ISSUER_URL=https://login.microsoftonline.com/your-tenant-id/v2.0
REPL_ID=your_application_client_id
```

**Note**: The application uses the `REPL_ID` environment variable for the client ID regardless of the OIDC provider. This is maintained for backward compatibility.

---

## Admin Access Setup

The application requires at least one admin user to upload resources and manage the system.

### Promoting a User to Admin

Admins are managed through direct database access for security. There is **no API endpoint** to promote users to prevent unauthorized access elevation.

#### Step 1: Create Your User Account

1. Log in to the application using your OIDC provider
2. This creates your user record in the database

#### Step 2: Promote User to Admin

**Using psql (PostgreSQL command-line):**

```bash
# Connect to database
psql $DATABASE_URL

# Or connect with credentials:
psql -h localhost -U nfrs_app -d nfrs_ai_toolkit

# Find your user ID
SELECT id, email FROM users;

# Promote to admin (replace YOUR_USER_ID with actual ID from above)
UPDATE users SET is_admin = 1 WHERE id = 'YOUR_USER_ID';

# Verify
SELECT id, email, is_admin FROM users;

# Exit
\q
```

**Using Database Management Tool (e.g., pgAdmin, DBeaver):**

1. Connect to the `nfrs_ai_toolkit` database
2. Navigate to the `users` table
3. Find your user record
4. Update the `is_admin` column to `1`
5. Save changes

**Using Replit Database Tool (if on Replit):**

1. Click "Tools" in the left sidebar
2. Select "Database"
3. Click "Query" to open SQL console
4. Run the SQL commands shown above

### Accessing Admin Panel

Once promoted to admin:

1. Log in to the application
2. On the Home page, you'll see an "Admin Panel" link (visible only to admins)
3. Click to access the admin panel at `/admin`
4. Upload files, view audit logs, and manage resources

---

## File Upload Configuration

Admin file uploads are stored in the `admin_uploads` directory (outside the web root for security).

### Upload Limits

- Maximum file size: **10 MB** (configurable in `server/routes.ts`)
- Allowed file types: All types (MIME type validation included)
- Files stored with UUID filenames to prevent conflicts

### Audit Logging

All admin actions are logged to:
- Console output (captured by systemd/Docker logs)
- `admin_audit.log` file in the application root

Example audit log entry:
```
[2025-11-08T15:30:45.123Z] UPLOAD - User: admin@nfrs.gov.uk - File: policy-2114.pdf (Original: POL 2114 AI Policy.pdf)
```

---

## Database Management

### Running Migrations

When schema changes are made:

```bash
# Development
npm run db:push

# If warned about data loss, force push:
npm run db:push --force
```

### Database Backup

**PostgreSQL Backup:**

```bash
# Create backup
pg_dump -U nfrs_app -d nfrs_ai_toolkit -F c -b -v -f nfrs_backup_$(date +%Y%m%d).dump

# Restore backup
pg_restore -U nfrs_app -d nfrs_ai_toolkit -v nfrs_backup_20251108.dump
```

### Database Maintenance

```bash
# Vacuum and analyze (recommended monthly)
sudo -u postgres psql -d nfrs_ai_toolkit -c "VACUUM ANALYZE;"
```

---

## Monitoring and Maintenance

### View Application Logs

**Systemd:**
```bash
sudo journalctl -u nfrs-ai-toolkit -f
```

**Docker:**
```bash
docker-compose logs -f app
```

### Monitor Performance

```bash
# Check service status
sudo systemctl status nfrs-ai-toolkit

# Monitor resource usage
htop

# Check database connections
sudo -u postgres psql -c "SELECT count(*) FROM pg_stat_activity WHERE datname = 'nfrs_ai_toolkit';"
```

### Restart Application

**Systemd:**
```bash
sudo systemctl restart nfrs-ai-toolkit
```

**Docker:**
```bash
docker-compose restart app
```

---

## Security Considerations

### Critical Security Measures

1. **Change default passwords**: Never use example passwords in production
2. **Use strong SESSION_SECRET**: Generate with `openssl rand -base64 32`
3. **Enable HTTPS**: Always use SSL/TLS in production
4. **Configure firewall**: Only open necessary ports (80, 443, 22)
5. **Regular updates**: Keep Node.js, PostgreSQL, and system packages updated
6. **Database access**: Restrict PostgreSQL to localhost unless necessary
7. **File permissions**: Ensure `admin_uploads` directory is not web-accessible
8. **Audit logs**: Regularly review `admin_audit.log` for suspicious activity
9. **Admin promotion**: Only promote trusted users to admin via database

### Recommended Security Hardening

```bash
# Restrict admin_uploads directory permissions
sudo chown -R nfrsapp:nfrsapp /opt/nfrs-ai-toolkit/admin_uploads
sudo chmod 750 /opt/nfrs-ai-toolkit/admin_uploads

# Secure .env file
sudo chmod 600 /opt/nfrs-ai-toolkit/.env

# Configure PostgreSQL to only accept local connections
sudo nano /etc/postgresql/*/main/pg_hba.conf
# Set: local   all   nfrs_app   md5
sudo systemctl reload postgresql

# Enable automatic security updates
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

---

## Troubleshooting

### Application Won't Start

```bash
# Check logs
sudo journalctl -u nfrs-ai-toolkit -n 50

# Common issues:
# 1. Database connection - verify DATABASE_URL
# 2. Missing SESSION_SECRET - check .env file
# 3. Port already in use - check with: sudo lsof -i :5000
```

### Database Connection Errors

```bash
# Test database connection
psql $DATABASE_URL -c "SELECT 1;"

# If connection fails:
# 1. Check PostgreSQL is running: sudo systemctl status postgresql
# 2. Verify credentials in DATABASE_URL
# 3. Check PostgreSQL logs: sudo tail -f /var/log/postgresql/postgresql-*-main.log
```

### Authentication Issues

```bash
# Verify OIDC configuration
# Check ISSUER_URL is accessible
curl -I $ISSUER_URL/.well-known/openid-configuration

# Clear sessions if stuck
# Delete from PostgreSQL:
psql $DATABASE_URL -c "DELETE FROM sessions;"
```

### File Upload Failures

```bash
# Check admin_uploads directory exists and is writable
ls -la admin_uploads/
sudo chown -R nfrsapp:nfrsapp admin_uploads/

# Check disk space
df -h
```

---

## Development Setup

For local development:

```bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Initialize database
npm run db:push

# Start development server
npm run dev

# Access at http://localhost:5000
```

---

## Production Checklist

Before going live:

- [ ] Change all default passwords
- [ ] Generate secure SESSION_SECRET
- [ ] Configure SSL/TLS certificate
- [ ] Set up automated backups
- [ ] Configure firewall rules
- [ ] Test authentication flow
- [ ] Promote at least one admin user
- [ ] Test file upload/download
- [ ] Review security hardening
- [ ] Set up monitoring/alerting
- [ ] Document admin procedures
- [ ] Train staff on system use
- [ ] Test WCAG accessibility
- [ ] Verify responsive design on multiple devices

---

## Support and Maintenance

### Regular Maintenance Tasks

- **Daily**: Review audit logs for admin actions
- **Weekly**: Check application and system logs for errors
- **Monthly**: Database maintenance (VACUUM ANALYZE)
- **Monthly**: Review and rotate audit logs
- **Quarterly**: Update dependencies (`npm audit`, `npm outdated`)
- **Quarterly**: Review user access and admin permissions
- **Annually**: Security audit and penetration testing

### Updating the Application

```bash
# Pull latest code
cd /opt/nfrs-ai-toolkit
sudo -u nfrsapp git pull

# Install dependencies
sudo -u nfrsapp npm install

# Run database migrations
sudo -u nfrsapp npm run db:push

# Rebuild application
sudo -u nfrsapp npm run build

# Restart service
sudo systemctl restart nfrs-ai-toolkit
```

---

## License

MIT License - See LICENSE file for details.

---

## Contact

For technical support or questions about deployment, contact your IT department or the application development team.

---

**Built with ❤️ for Nottinghamshire Fire & Rescue Service**
