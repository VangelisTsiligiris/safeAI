import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, requireAdmin } from "./replitAuth";
import { assessCompliance } from "../client/src/utils/policyLogic";
import { insertWorkshopSessionSchema, insertComplianceAssessmentSchema } from "@shared/schema";
import { SCENARIOS } from "../client/src/data/scenarios";
import { AI_FUNDAMENTALS, RISK_ETHICS_FRAMEWORK } from "../client/src/data/frameworkContent";
import { POLICY_EXCERPTS, NFRS_CORE_CODE } from "../client/src/data/policyExcerpts";
import { DEPARTMENTS, KEY_CONTACTS } from "../client/src/data/constants";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);

  // Rate limiting for admin login (simple in-memory implementation)
  const loginAttempts = new Map<string, { count: number; firstAttempt: number }>();
  const MAX_LOGIN_ATTEMPTS = 5;
  const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes

  // Admin password login route (no OIDC required)
  app.post('/api/admin/login', async (req, res) => {
    try {
      const { password } = req.body;
      const ADMIN_PASSWORD = 'admin2025';
      const clientIP = req.ip || req.socket.remoteAddress || 'unknown';

      if (!password) {
        return res.status(400).json({ error: "Password is required" });
      }

      // Check rate limiting
      const attemptData = loginAttempts.get(clientIP);
      const now = Date.now();

      if (attemptData) {
        // Reset if lockout period has passed
        if (now - attemptData.firstAttempt > LOCKOUT_DURATION) {
          loginAttempts.delete(clientIP);
        } else if (attemptData.count >= MAX_LOGIN_ATTEMPTS) {
          const timeLeft = Math.ceil((LOCKOUT_DURATION - (now - attemptData.firstAttempt)) / 1000 / 60);
          return res.status(429).json({ 
            error: `Too many failed attempts. Please try again in ${timeLeft} minutes.` 
          });
        }
      }

      if (password === ADMIN_PASSWORD) {
        // Clear failed attempts on successful login
        loginAttempts.delete(clientIP);
        
        // Regenerate session to prevent session fixation
        req.session.regenerate((err) => {
          if (err) {
            console.error("Session regeneration error:", err);
            return res.status(500).json({ error: "Login failed" });
          }

          // Create admin session with timeout (1 hour)
          const sessionData = req.session as any;
          sessionData.isAdminPassword = true;
          sessionData.adminPasswordLoginTime = Date.now();
          res.json({ success: true, message: "Admin access granted" });
        });
      } else {
        // Record failed attempt
        if (attemptData) {
          attemptData.count++;
        } else {
          loginAttempts.set(clientIP, { count: 1, firstAttempt: now });
        }
        
        const remainingAttempts = MAX_LOGIN_ATTEMPTS - (attemptData?.count || 1);
        res.status(401).json({ 
          error: "Invalid password",
          remainingAttempts: Math.max(0, remainingAttempts)
        });
      }
    } catch (error) {
      console.error("Error during admin login:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Admin logout route
  app.post('/api/admin/logout', async (req, res) => {
    try {
      const sessionData = req.session as any;
      if (sessionData.isAdminPassword) {
        delete sessionData.isAdminPassword;
        delete sessionData.adminPasswordLoginTime;
      }
      res.json({ success: true, message: "Logged out successfully" });
    } catch (error) {
      console.error("Error during admin logout:", error);
      res.status(500).json({ error: "Logout failed" });
    }
  });

  // Admin session check route with timeout validation
  app.get('/api/admin/session', async (req, res) => {
    const sessionData = req.session as any;
    const isAdminPassword = sessionData?.isAdminPassword === true;
    const loginTime = sessionData?.adminPasswordLoginTime;
    
    // Check if session is expired (1 hour timeout)
    if (isAdminPassword && loginTime) {
      const sessionAge = Date.now() - loginTime;
      const SESSION_TIMEOUT = 60 * 60 * 1000; // 1 hour
      
      if (sessionAge > SESSION_TIMEOUT) {
        // Session expired, clear it
        delete sessionData.isAdminPassword;
        delete sessionData.adminPasswordLoginTime;
        return res.json({ isAdminPassword: false, expired: true });
      }
    }
    
    res.json({ isAdminPassword });
  });

  // Auth route - get current user
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // Workshop Content Routes (protected)
  app.get("/api/workshop/scenarios", isAuthenticated, async (req, res) => {
    res.json(SCENARIOS);
  });

  // Facilitator notes endpoint - admin only
  app.get("/api/workshop/scenarios/facilitator-notes", requireAdmin, async (req, res) => {
    // Return facilitator notes for all scenarios
    const facilitatorNotes: Record<string, string[]> = {
      'scenario-1': [
        'Key risks: Hallucination (AI inventing facts), outdated information, lack of real-time situational awareness',
        'Relevant clauses: Section 6 (Accuracy - human review mandatory), Section 7 (Disclosure required), Section 6 (Public Trust)',
        'Potential safeguards: Template-based AI prompts, mandatory review by Incident Commander, clear "AI-assisted" labeling, pre-approved messaging frameworks',
        'Discussion point: Balance between speed and accuracy - is faster communication always better?',
        'Consider: Could AI draft but human verify? What approval process ensures accuracy without losing speed benefit?',
      ],
      'scenario-2': [
        'Key risk: Bias - AI trained on historical data may deprioritize vulnerable groups who most need services',
        'Relevant clauses: Section 6 (Bias and Discrimination), NFRS Core Code of Ethics (Respect and Equality)',
        'Bias concern: AI trained on historical data may perpetuate biases (e.g., deprioritizing certain demographics or postcodes)',
        'GDPR Article 22: Right not to be subject to automated decision-making in significant decisions',
        'Relevant clause: Section 6 - Bias and Discrimination; NFRS Core Code of Ethics',
        'Alternative: Could AI analyze anonymized/aggregated data to identify high-risk patterns, with human practitioners making individual prioritization decisions?',
        'Discussion: Is this a decision AI should make, or should humans always retain control over vulnerable person safeguarding?',
      ],
      'scenario-3': [
        'Key distinction: Microsoft Copilot (M365 enterprise) vs public ChatGPT - data residency and security differ significantly',
        'If using approved M365 Copilot: May be permissible IF personal data is removed/anonymized first',
        'If using public AI: Likely prohibited under Section 8 (confidential/sensitive data)',
        'Safeguards: Data anonymization before AI processing, human review of all outputs, clear disclosure in final briefing',
        'Relevant clauses: Section 6 (Confidentiality), Section 8 (Prohibited Use), Section 6 (Cyber Security)',
        'Discussion: What level of anonymization is "safe enough"? Could pseudonymized data still be re-identified?',
        'Consider: Does the time-saving justify the residual risk? Are there non-AI workflow improvements that achieve similar efficiency?',
      ],
      'scenario-4': [
        'Critical risk: Hallucination - AI inventing non-existent procedures or equipment specifications could lead to operational failures or firefighter deaths',
        'Copyright concern: If AI training data included copyrighted training materials from other fire services, outputs might infringe IP rights',
        'Accountability: Section 6 - Human remains accountable for all AI-generated content. Who validates technical accuracy?',
        'Relevant clauses: Section 6 (Accuracy), Section 6 (Copyright/IP), Section 7 (Disclosure), Section 6 (Accountability)',
        'Safeguards: Expert technical review by qualified BA instructors, cross-reference with authoritative sources (manufacturer guidance, NFCC), pilot testing before wider use, clear version control and change tracking',
        'Discussion: Is AI-generated training content fundamentally different from human-authored content (which can also contain errors)? What validation is "good enough" for life-critical training?',
        'Consider: Could AI assist with lower-risk content (e.g., general safety awareness) before progressing to operational skills training?',
      ],
    };
    res.json(facilitatorNotes);
  });

  app.get("/api/workshop/fundamentals", isAuthenticated, async (req, res) => {
    res.json(AI_FUNDAMENTALS);
  });

  app.get("/api/workshop/risks", isAuthenticated, async (req, res) => {
    res.json(RISK_ETHICS_FRAMEWORK);
  });

  app.get("/api/workshop/policy", isAuthenticated, async (req, res) => {
    res.json({ excerpts: POLICY_EXCERPTS, coreCode: NFRS_CORE_CODE });
  });

  // Workshop Session Management (protected)
  app.post("/api/workshop/sessions", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertWorkshopSessionSchema.parse(req.body);
      const session = await storage.createWorkshopSession(validatedData);
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/workshop/sessions/:id", isAuthenticated, async (req, res) => {
    const session = await storage.getWorkshopSession(req.params.id);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }
    res.json(session);
  });

  app.patch("/api/workshop/sessions/:id", isAuthenticated, async (req, res) => {
    try {
      const session = await storage.updateWorkshopSession(req.params.id, req.body);
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Compliance Assessment Routes (protected)
  app.post("/api/compliance/assess", isAuthenticated, async (req, res) => {
    try {
      const { responses } = req.body;
      const decision = assessCompliance(responses);
      res.json(decision);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/compliance/assessments", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertComplianceAssessmentSchema.parse(req.body);
      const assessment = await storage.createComplianceAssessment(validatedData);
      res.json(assessment);
    } catch (error: any) {
      console.error('[ERROR] Failed to save compliance assessment:', error.message);
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/compliance/assessments/:id", isAuthenticated, async (req, res) => {
    const assessment = await storage.getComplianceAssessment(req.params.id);
    if (!assessment) {
      return res.status(404).json({ error: "Assessment not found" });
    }
    res.json(assessment);
  });

  app.get("/api/compliance/assessments", isAuthenticated, async (req, res) => {
    const assessments = await storage.getAllComplianceAssessments();
    res.json(assessments);
  });

  // Reference Data Routes (protected)
  app.get("/api/reference/departments", isAuthenticated, async (req, res) => {
    res.json(DEPARTMENTS);
  });

  app.get("/api/reference/contacts", isAuthenticated, async (req, res) => {
    res.json(KEY_CONTACTS);
  });

  // Resources Routes (public for authenticated users, admin-only for uploads/deletions)
  app.get("/api/resources", isAuthenticated, async (req, res) => {
    try {
      const uploadsDir = path.join(process.cwd(), "admin_uploads");
      if (!fs.existsSync(uploadsDir)) {
        return res.json([]);
      }
      const files = fs.readdirSync(uploadsDir);
      const resources = files.map(filename => {
        const filePath = path.join(uploadsDir, filename);
        const stats = fs.statSync(filePath);
        return {
          id: filename,
          name: filename,
          size: stats.size,
          uploadedAt: stats.mtime.toISOString(),
        };
      });
      res.json(resources);
    } catch (error: any) {
      console.error("Error listing resources:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/resources/:id", isAuthenticated, async (req, res) => {
    try {
      const filename = req.params.id;
      const uploadsDir = path.join(process.cwd(), "admin_uploads");
      const filePath = path.normalize(path.join(uploadsDir, filename));

      // Security: prevent path traversal with normalized paths
      if (!filePath.startsWith(uploadsDir + path.sep) && filePath !== uploadsDir) {
        return res.status(403).json({ error: "Access denied" });
      }

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "Resource not found" });
      }

      // Set appropriate headers for download
      const ext = path.extname(filename).toLowerCase();
      const mimeTypes: Record<string, string> = {
        '.pdf': 'application/pdf',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.doc': 'application/msword',
        '.txt': 'text/plain',
        '.csv': 'text/csv',
      };
      
      const mimeType = mimeTypes[ext] || 'application/octet-stream';
      res.setHeader('Content-Type', mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error: any) {
      console.error("Error downloading resource:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // PDF Export placeholder routes (to be implemented with actual PDF generation)
  app.post("/api/export/action-plan", async (req, res) => {
    // This will be enhanced with actual PDF generation library
    res.json({ 
      message: "PDF generation endpoint ready",
      data: req.body 
    });
  });

  app.post("/api/export/workshop-summary", async (req, res) => {
    // This will be enhanced with actual PDF generation library
    res.json({ 
      message: "PDF generation endpoint ready",
      data: req.body 
    });
  });

  app.post("/api/export/compliance-result", async (req, res) => {
    // This will be enhanced with actual PDF generation library
    res.json({ 
      message: "PDF generation endpoint ready",
      data: req.body 
    });
  });

  // Admin Routes (protected with requireAdmin middleware)
  const uploadsDir = path.join(process.cwd(), "admin_uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const upload = multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => {
        cb(null, uploadsDir);
      },
      filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        const safeFilename = `${randomUUID()}${ext}`;
        cb(null, safeFilename);
      },
    }),
    limits: {
      fileSize: 10 * 1024 * 1024,
    },
    fileFilter: (req, file, cb) => {
      const allowedMimes = [
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'application/msword',
        'text/plain',
        'text/csv',
      ];
      if (allowedMimes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error(`Unsupported file type: ${file.mimetype}`));
      }
    },
  });

  function logAdminAction(userId: string, action: string, details: any) {
    const timestamp = new Date().toISOString();
    const logEntry = JSON.stringify({ timestamp, userId, action, details });
    console.log(`[ADMIN_AUDIT] ${logEntry}`);
    const auditLogPath = path.join(process.cwd(), "admin_audit.log");
    fs.appendFileSync(auditLogPath, logEntry + '\n', 'utf8');
  }

  app.get("/api/admin/check", async (req: any, res) => {
    try {
      // Check for password-based admin session first
      const sessionData = req.session as any;
      const isAdminPassword = sessionData?.isAdminPassword === true;
      const loginTime = sessionData?.adminPasswordLoginTime;

      if (isAdminPassword && loginTime) {
        // Validate session timeout (1 hour)
        const sessionAge = Date.now() - loginTime;
        const SESSION_TIMEOUT = 60 * 60 * 1000; // 1 hour
        
        if (sessionAge <= SESSION_TIMEOUT) {
          // Valid password-based admin session
          return res.json({ isAdmin: true });
        }
      }

      // Check for OIDC-based admin
      if (req.isAuthenticated() && req.user?.claims?.sub) {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        return res.json({ isAdmin: user?.isAdmin === 1 });
      }

      // Not admin
      res.json({ isAdmin: false });
    } catch (error) {
      console.error("Error checking admin status:", error);
      res.status(500).json({ message: "Failed to check admin status" });
    }
  });

  app.post("/api/admin/upload", requireAdmin, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'admin-password';
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      logAdminAction(userId, 'FILE_UPLOAD', {
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        mimetype: req.file.mimetype,
      });

      res.json({
        success: true,
        file: {
          id: req.file.filename,
          originalName: req.file.originalname,
          size: req.file.size,
          uploadedAt: new Date().toISOString(),
        },
      });
    } catch (error: any) {
      console.error("File upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/admin/resources", requireAdmin, async (req: any, res) => {
    try {
      const files = fs.readdirSync(uploadsDir);
      const resources = files.map(filename => {
        const filePath = path.join(uploadsDir, filename);
        const stats = fs.statSync(filePath);
        return {
          id: filename,
          name: filename,
          size: stats.size,
          uploadedAt: stats.mtime.toISOString(),
        };
      });
      res.json(resources);
    } catch (error: any) {
      console.error("Error listing resources:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/admin/resources/:id", requireAdmin, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'admin-password';
      const oldFilename = req.params.id;
      let { newName } = req.body;

      if (!newName || !newName.trim()) {
        return res.status(400).json({ error: "New filename is required" });
      }

      newName = newName.trim();

      // Security: sanitize filename - prevent path traversal
      if (newName.includes('/') || newName.includes('\\') || newName.includes('..')) {
        return res.status(400).json({ error: "Invalid filename - path separators not allowed" });
      }

      // Validate filename - strict whitelist with proper extension support
      // Prevents hidden files (starting with .) and allows legitimate multi-dot filenames
      const filenameRegex = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,127}$/;
      if (!filenameRegex.test(newName)) {
        return res.status(400).json({ error: "Invalid filename - must start with alphanumeric, max 128 chars, allowed: letters, numbers, spaces, dots, hyphens, underscores" });
      }

      // Validate file extension against whitelist
      const ext = path.extname(newName).toLowerCase();
      const allowedExtensions = ['.pdf', '.docx', '.xlsx', '.xls', '.doc', '.txt', '.csv'];
      if (!ext || !allowedExtensions.includes(ext)) {
        return res.status(400).json({ error: `Invalid file extension. Allowed: ${allowedExtensions.join(', ')}` });
      }

      const oldFilePath = path.normalize(path.join(uploadsDir, oldFilename));
      const newFilePath = path.normalize(path.join(uploadsDir, newName));

      // Security: prevent path traversal - check normalized paths
      if (!oldFilePath.startsWith(uploadsDir + path.sep) || !newFilePath.startsWith(uploadsDir + path.sep)) {
        return res.status(403).json({ error: "Access denied" });
      }

      if (!fs.existsSync(oldFilePath)) {
        return res.status(404).json({ error: "Resource not found" });
      }

      if (fs.existsSync(newFilePath) && oldFilePath !== newFilePath) {
        return res.status(409).json({ error: "A file with this name already exists" });
      }

      fs.renameSync(oldFilePath, newFilePath);
      logAdminAction(userId, 'FILE_RENAME', { 
        oldFilename, 
        newFilename: newName 
      });
      
      res.json({ 
        success: true, 
        message: "Resource renamed successfully",
        newId: newName
      });
    } catch (error: any) {
      console.error("Error updating resource:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/resources/:id", requireAdmin, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub || 'admin-password';
      const filename = req.params.id;
      const filePath = path.normalize(path.join(uploadsDir, filename));

      // Security: prevent path traversal with normalized paths
      if (!filePath.startsWith(uploadsDir + path.sep)) {
        return res.status(403).json({ error: "Access denied" });
      }

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "Resource not found" });
      }

      fs.unlinkSync(filePath);
      logAdminAction(userId, 'FILE_DELETE', { filename });

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting resource:", error);
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
