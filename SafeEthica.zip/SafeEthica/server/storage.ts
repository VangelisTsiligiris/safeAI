import { 
  type WorkshopSession, 
  type InsertWorkshopSession,
  type ComplianceAssessment,
  type InsertComplianceAssessment,
  type User,
  type UpsertUser,
  workshopSessions,
  complianceAssessments,
  users
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Workshop Sessions
  getWorkshopSession(id: string): Promise<WorkshopSession | undefined>;
  createWorkshopSession(session: InsertWorkshopSession): Promise<WorkshopSession>;
  updateWorkshopSession(id: string, session: Partial<InsertWorkshopSession>): Promise<WorkshopSession | undefined>;
  
  // Compliance Assessments
  getComplianceAssessment(id: string): Promise<ComplianceAssessment | undefined>;
  createComplianceAssessment(assessment: InsertComplianceAssessment): Promise<ComplianceAssessment>;
  getAllComplianceAssessments(): Promise<ComplianceAssessment[]>;
}

export class MemStorage implements IStorage {
  private workshopSessions: Map<string, WorkshopSession>;
  private complianceAssessments: Map<string, ComplianceAssessment>;
  private users: Map<string, User>;

  constructor() {
    this.workshopSessions = new Map();
    this.complianceAssessments = new Map();
    this.users = new Map();
  }

  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // Only store profile fields, never store OAuth tokens
    const existingUser = this.users.get(userData.id!);
    const safeUserData = {
      id: userData.id,
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      profileImageUrl: userData.profileImageUrl,
      isAdmin: existingUser?.isAdmin ?? 0,
    };
    
    const user: User = {
      ...safeUserData,
      createdAt: existingUser?.createdAt ?? new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id!, user);
    return user;
  }

  // Workshop Sessions
  async getWorkshopSession(id: string): Promise<WorkshopSession | undefined> {
    return this.workshopSessions.get(id);
  }

  async createWorkshopSession(insertSession: InsertWorkshopSession): Promise<WorkshopSession> {
    const id = randomUUID();
    const session: WorkshopSession = {
      ...insertSession,
      id,
      createdAt: new Date(),
    };
    this.workshopSessions.set(id, session);
    return session;
  }

  async updateWorkshopSession(
    id: string,
    updates: Partial<InsertWorkshopSession>
  ): Promise<WorkshopSession | undefined> {
    const session = this.workshopSessions.get(id);
    if (!session) return undefined;

    const updated: WorkshopSession = {
      ...session,
      ...updates,
    };
    this.workshopSessions.set(id, updated);
    return updated;
  }

  // Compliance Assessments
  async getComplianceAssessment(id: string): Promise<ComplianceAssessment | undefined> {
    return this.complianceAssessments.get(id);
  }

  async createComplianceAssessment(
    insertAssessment: InsertComplianceAssessment
  ): Promise<ComplianceAssessment> {
    const id = randomUUID();
    const assessment: ComplianceAssessment = {
      ...insertAssessment,
      id,
      createdAt: new Date(),
    };
    this.complianceAssessments.set(id, assessment);
    return assessment;
  }

  async getAllComplianceAssessments(): Promise<ComplianceAssessment[]> {
    return Array.from(this.complianceAssessments.values());
  }
}

// PostgreSQL storage implementation
export class PgStorage implements IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // Only store profile fields, never store OAuth tokens
    // Preserve existing isAdmin flag if user already exists
    const safeUserData = {
      id: userData.id,
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      profileImageUrl: userData.profileImageUrl,
      isAdmin: 0,
    };
    
    const [user] = await db
      .insert(users)
      .values(safeUserData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: safeUserData.email,
          firstName: safeUserData.firstName,
          lastName: safeUserData.lastName,
          profileImageUrl: safeUserData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Workshop Sessions
  async getWorkshopSession(id: string): Promise<WorkshopSession | undefined> {
    const result = await db.select().from(workshopSessions).where(eq(workshopSessions.id, id));
    return result[0];
  }

  async createWorkshopSession(insertSession: InsertWorkshopSession): Promise<WorkshopSession> {
    const result = await db.insert(workshopSessions).values(insertSession).returning();
    return result[0];
  }

  async updateWorkshopSession(
    id: string,
    updates: Partial<InsertWorkshopSession>
  ): Promise<WorkshopSession | undefined> {
    const result = await db
      .update(workshopSessions)
      .set(updates)
      .where(eq(workshopSessions.id, id))
      .returning();
    return result[0];
  }

  // Compliance Assessments
  async getComplianceAssessment(id: string): Promise<ComplianceAssessment | undefined> {
    const result = await db.select().from(complianceAssessments).where(eq(complianceAssessments.id, id));
    return result[0];
  }

  async createComplianceAssessment(
    insertAssessment: InsertComplianceAssessment
  ): Promise<ComplianceAssessment> {
    const result = await db.insert(complianceAssessments).values(insertAssessment).returning();
    return result[0];
  }

  async getAllComplianceAssessments(): Promise<ComplianceAssessment[]> {
    return await db.select().from(complianceAssessments);
  }
}

// Use PostgreSQL storage in production, MemStorage for development if needed
export const storage = new PgStorage();
