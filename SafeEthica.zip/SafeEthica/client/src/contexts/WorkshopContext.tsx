import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { type WorkshopSession, type ScenarioResponse } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

interface WorkshopContextValue {
  sessionId: string | null;
  department: string;
  scenarioResponses: Record<string, ScenarioResponse>;
  actionPlan: {
    department: string;
    aiUseCases: string;
    riskMitigation: string;
    trainingNeeds: string;
    governanceTouchpoints: string[];
    targetDates: string;
  } | null;
  setDepartment: (dept: string) => void;
  updateScenarioResponse: (scenarioId: string, response: Partial<ScenarioResponse>) => void;
  setActionPlan: (plan: WorkshopContextValue['actionPlan']) => void;
  saveSession: () => Promise<string>;
  loadSession: (id: string) => Promise<void>;
  clearSession: () => void;
}

const WorkshopContext = createContext<WorkshopContextValue | null>(null);

export function WorkshopProvider({ children }: { children: ReactNode }) {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [department, setDepartment] = useState('');
  const [scenarioResponses, setScenarioResponses] = useState<Record<string, ScenarioResponse>>({});
  const [actionPlan, setActionPlan] = useState<WorkshopContextValue['actionPlan']>(null);

  const updateScenarioResponse = (scenarioId: string, response: Partial<ScenarioResponse>) => {
    setScenarioResponses(prev => ({
      ...prev,
      [scenarioId]: {
        ...prev[scenarioId],
        ...response,
        scenarioId,
      } as ScenarioResponse,
    }));
  };

  const saveSession = async (): Promise<string> => {
    const sessionData = {
      department,
      scenarioResponses: Object.keys(scenarioResponses).length > 0 ? scenarioResponses : undefined,
      actionPlan: actionPlan || undefined,
    };

    if (sessionId) {
      const res = await apiRequest('PATCH', `/api/workshop/sessions/${sessionId}`, sessionData);
      await res.json();
      return sessionId;
    } else {
      const res = await apiRequest('POST', '/api/workshop/sessions', sessionData);
      const session = await res.json() as WorkshopSession;
      setSessionId(session.id);
      return session.id;
    }
  };

  const loadSession = async (id: string) => {
    const res = await apiRequest('GET', `/api/workshop/sessions/${id}`, undefined);
    const session = await res.json() as WorkshopSession;
    
    setSessionId(session.id);
    setDepartment(session.department || '');
    setScenarioResponses(session.scenarioResponses as Record<string, ScenarioResponse> || {});
    setActionPlan(session.actionPlan as WorkshopContextValue['actionPlan'] || null);
  };

  const clearSession = () => {
    setSessionId(null);
    setDepartment('');
    setScenarioResponses({});
    setActionPlan(null);
  };

  const value: WorkshopContextValue = {
    sessionId,
    department,
    scenarioResponses,
    actionPlan,
    setDepartment,
    updateScenarioResponse,
    setActionPlan,
    saveSession,
    loadSession,
    clearSession,
  };

  return <WorkshopContext.Provider value={value}>{children}</WorkshopContext.Provider>;
}

export function useWorkshop() {
  const context = useContext(WorkshopContext);
  if (!context) {
    throw new Error('useWorkshop must be used within WorkshopProvider');
  }
  return context;
}
