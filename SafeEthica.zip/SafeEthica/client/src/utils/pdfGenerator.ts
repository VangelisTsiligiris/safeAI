import { jsPDF } from 'jspdf';
import type { ComplianceDecision } from '@shared/schema';
import type { ActionPlan } from '@shared/schema';

// NFRS brand colors
const NFRS_RED = '#C8102E';
const DARK_GREY = '#2D2D2D';
const LIGHT_GREY = '#F5F5F5';

function addNFRSHeader(doc: jsPDF, title: string) {
  // Header with NFRS branding
  doc.setFillColor(NFRS_RED);
  doc.rect(0, 0, 210, 15, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('NFRS AI Toolkit', 15, 10);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(title, 15, 14);
  
  // Reset text color
  doc.setTextColor(DARK_GREY);
}

function addFooter(doc: jsPDF, pageNumber: number) {
  const pageHeight = doc.internal.pageSize.height;
  doc.setFontSize(8);
  doc.setTextColor(128, 128, 128);
  doc.text(`POL 2114 - Artificial Intelligence Policy | Page ${pageNumber}`, 15, pageHeight - 10);
  doc.text(`Generated: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`, 150, pageHeight - 10);
}

export function generateComplianceResultPDF(
  department: string,
  task: string,
  tool: string,
  purpose: string,
  decision: ComplianceDecision
): void {
  const doc = new jsPDF();
  
  addNFRSHeader(doc, 'Compliance Assessment Result');
  
  let y = 25;
  
  // Decision outcome badge
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  const outcomeColor: [number, number, number] = decision.outcome === 'PERMITTED' ? [16, 185, 129] :
                        decision.outcome === 'REFER' ? [245, 158, 11] : [220, 38, 38];
  doc.setTextColor(...outcomeColor);
  doc.text(`Decision: ${decision.outcome}`, 15, y);
  y += 10;
  
  // Explanation
  doc.setTextColor(DARK_GREY);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitExplanation = doc.splitTextToSize(decision.explanation, 180);
  doc.text(splitExplanation, 15, y);
  y += splitExplanation.length * 5 + 10;
  
  // Task Summary
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Task Summary', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Department: ${department}`, 15, y);
  y += 5;
  doc.text(`AI Tool: ${tool}`, 15, y);
  y += 5;
  doc.text(`Purpose: ${purpose}`, 15, y);
  y += 7;
  
  const splitTask = doc.splitTextToSize(`Task: ${task}`, 180);
  doc.text(splitTask, 15, y);
  y += splitTask.length * 5 + 10;
  
  // Safeguards (if any)
  if (decision.safeguards.length > 0) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Required Safeguards', 15, y);
    y += 7;
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    decision.safeguards.forEach((safeguard) => {
      const splitSafeguard = doc.splitTextToSize(`• ${safeguard}`, 175);
      doc.text(splitSafeguard, 15, y);
      y += splitSafeguard.length * 5 + 2;
    });
    y += 5;
  }
  
  // Referrals (if any)
  if (decision.referrals.length > 0) {
    if (y > 250) {
      doc.addPage();
      addNFRSHeader(doc, 'Compliance Assessment Result');
      y = 25;
    }
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Contact for Approval', 15, y);
    y += 7;
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    decision.referrals.forEach((referral) => {
      doc.text(`${referral.contact} (${referral.role})`, 15, y);
      y += 5;
      doc.text(`Reason: ${referral.reason}`, 15, y);
      y += 5;
      if (referral.email) {
        doc.text(`Email: ${referral.email}`, 15, y);
        y += 5;
      }
      y += 3;
    });
  }
  
  // Policy references
  if (y > 240) {
    doc.addPage();
    addNFRSHeader(doc, 'Compliance Assessment Result');
    y = 25;
  }
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Relevant Policy Clauses', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  decision.policyClauses.forEach((clause) => {
    doc.text(`• ${clause}`, 15, y);
    y += 5;
  });
  
  addFooter(doc, 1);
  
  doc.save(`NFRS_AI_Compliance_${new Date().getTime()}.pdf`);
}

export function generateActionPlanPDF(actionPlan: ActionPlan): void {
  const doc = new jsPDF();
  
  addNFRSHeader(doc, 'Departmental AI Action Plan');
  
  let y = 25;
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`Department: ${actionPlan.department}`, 15, y);
  y += 10;
  
  // AI Use Cases
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Current or Planned AI Use Cases', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitUseCases = doc.splitTextToSize(actionPlan.aiUseCases, 180);
  doc.text(splitUseCases, 15, y);
  y += splitUseCases.length * 5 + 8;
  
  // Risk Mitigation
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Risk Mitigation Measures', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitMitigation = doc.splitTextToSize(actionPlan.riskMitigation, 180);
  doc.text(splitMitigation, 15, y);
  y += splitMitigation.length * 5 + 8;
  
  if (y > 240) {
    doc.addPage();
    addNFRSHeader(doc, 'Departmental AI Action Plan');
    y = 25;
  }
  
  // Training Needs
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Training and Guidance Needs', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitTraining = doc.splitTextToSize(actionPlan.trainingNeeds, 180);
  doc.text(splitTraining, 15, y);
  y += splitTraining.length * 5 + 8;
  
  // Governance Touchpoints
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Governance Touchpoints', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  actionPlan.governanceTouchpoints.forEach((touchpoint) => {
    doc.text(`• ${touchpoint}`, 15, y);
    y += 5;
  });
  y += 5;
  
  // Target Dates
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Target Dates and Milestones', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const splitDates = doc.splitTextToSize(actionPlan.targetDates, 180);
  doc.text(splitDates, 15, y);
  
  addFooter(doc, 1);
  
  doc.save(`NFRS_Action_Plan_${actionPlan.department}_${new Date().getTime()}.pdf`);
}

export function generateWorkshopSummaryPDF(): void {
  const doc = new jsPDF();
  
  addNFRSHeader(doc, 'Workshop Summary');
  
  let y = 25;
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('AI Governance Workshop Summary', 15, y);
  y += 10;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Workshop Date: ${new Date().toLocaleDateString()}`, 15, y);
  y += 10;
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Modules Completed', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const modules = [
    'AI Fundamentals for Fire Services',
    'Risk & Ethics Framework',
    'Interactive Scenarios (4 scenarios)',
    'Departmental Action Plans'
  ];
  
  modules.forEach((module) => {
    doc.text(`✓ ${module}`, 15, y);
    y += 5;
  });
  y += 10;
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Key Takeaways', 15, y);
  y += 7;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const takeaways = [
    'All departments recognize the need for human oversight and accountability in AI use',
    'Personal data protection is a critical concern across all AI applications',
    'Teams need practical guidance and training on POL 2114 implementation',
    'Engagement with IGO, ICT Security, and OD&I is essential for most AI use cases'
  ];
  
  takeaways.forEach((takeaway) => {
    const splitTakeaway = doc.splitTextToSize(`• ${takeaway}`, 175);
    doc.text(splitTakeaway, 15, y);
    y += splitTakeaway.length * 5 + 2;
  });
  
  addFooter(doc, 1);
  
  doc.save(`NFRS_Workshop_Summary_${new Date().getTime()}.pdf`);
}
