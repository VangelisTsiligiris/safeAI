import type { AssessmentResponses, ComplianceDecision, Risk, Referral } from "@shared/schema";
import { KEY_CONTACTS } from "@/data/constants";

export function assessCompliance(responses: AssessmentResponses): ComplianceDecision {
  let score = 0;
  const risks: Risk[] = [];
  const safeguards: string[] = [];
  const referrals: Referral[] = [];
  const policyClauses: string[] = [];

  // Critical - Personal Data (Section 8 Prohibited Use)
  if (responses.containsPersonalData === 'yes') {
    score += 100;
    risks.push({
      category: 'Data Protection',
      clause: 'POL 2114 Section 8',
      severity: 'CRITICAL',
      description: 'Personal data must not be entered into unapproved AI systems. This violates GDPR and Section 8 Prohibited Use.',
    });
    policyClauses.push('Section 8: Prohibited Use');
  }

  // High - Sensitive Information without approved tool
  if (responses.containsSensitiveInfo === 'yes' && responses.toolMeetsSecurity === 'no') {
    score += 50;
    risks.push({
      category: 'Confidentiality',
      clause: 'POL 2114 Section 6',
      severity: 'HIGH',
      description: 'Operationally sensitive information should only be processed by approved, secure AI tools.',
    });
    referrals.push({
      contact: KEY_CONTACTS.ictSecurity.contact,
      role: KEY_CONTACTS.ictSecurity.role,
      reason: 'Security assessment required for AI tool handling sensitive information',
      email: KEY_CONTACTS.ictSecurity.email,
      phone: KEY_CONTACTS.ictSecurity.phone,
    });
    policyClauses.push('Section 6: Cyber Security');
  }

  // High - Confidential exposure risk
  if (responses.exposesConfidential === 'yes') {
    score += 50;
    risks.push({
      category: 'Confidentiality Breach',
      clause: 'POL 2114 Section 6',
      severity: 'HIGH',
      description: 'Task poses risk of exposing confidential, commercially sensitive, or security-critical information.',
    });
    referrals.push({
      contact: KEY_CONTACTS.igo.contact,
      role: KEY_CONTACTS.igo.role,
      reason: 'Data protection impact assessment needed',
      email: KEY_CONTACTS.igo.email,
      phone: KEY_CONTACTS.igo.phone,
    });
    policyClauses.push('Section 6: Confidentiality');
  }

  // Medium - Tool not meeting security standards
  if (responses.toolMeetsSecurity === 'no') {
    score += 30;
    risks.push({
      category: 'Cyber Security',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'AI tool does not meet NFRS cyber security standards. ICT Security approval required.',
    });
    referrals.push({
      contact: KEY_CONTACTS.ictSecurity.contact,
      role: KEY_CONTACTS.ictSecurity.role,
      reason: 'Tool certification and security assessment required',
      email: KEY_CONTACTS.ictSecurity.email,
      phone: KEY_CONTACTS.ictSecurity.phone,
    });
    policyClauses.push('Section 6: Cyber Security');
  }

  // Medium - Copyright risk
  if (responses.copyrightRisk === 'yes') {
    score += 25;
    risks.push({
      category: 'Copyright / Intellectual Property',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'AI-generated content may infringe copyright or intellectual property rights.',
    });
    safeguards.push('Review AI outputs for potential copyright infringement before publication');
    safeguards.push('Ensure proper attribution where required');
    policyClauses.push('Section 6: Copyright and Intellectual Property');
  }

  // Medium - No verification
  if (responses.willVerifyOutputs === 'no') {
    score += 30;
    risks.push({
      category: 'Accuracy',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'AI outputs must be reviewed and verified by a competent human before use.',
    });
    policyClauses.push('Section 6: Accuracy');
  } else if (responses.willVerifyOutputs === 'yes') {
    safeguards.push('Human review and verification of all AI outputs mandatory before use');
    policyClauses.push('Section 6: Accuracy');
  }

  // Medium - Accountability not understood
  if (responses.understandsAccountability === 'no') {
    score += 20;
    risks.push({
      category: 'Accountability',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'You remain personally accountable for any content produced with AI assistance.',
    });
    policyClauses.push('Section 6: Accountability');
  } else if (responses.understandsAccountability === 'yes') {
    safeguards.push('User acknowledges personal accountability for AI-assisted content');
  }

  // Medium - Re-identification risk
  if (responses.reidentificationRisk === 'yes') {
    score += 35;
    risks.push({
      category: 'Data Protection',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'Pseudonymized data could be re-identified through AI processing, violating GDPR.',
    });
    referrals.push({
      contact: KEY_CONTACTS.igo.contact,
      role: KEY_CONTACTS.igo.role,
      reason: 'Data protection assessment for pseudonymized data processing',
      email: KEY_CONTACTS.igo.email,
      phone: KEY_CONTACTS.igo.phone,
    });
    policyClauses.push('Section 6: Confidentiality');
  }

  // High - Bias / Discrimination concern
  if (responses.couldCauseBias === 'yes') {
    score += 40;
    risks.push({
      category: 'Bias and Discrimination',
      clause: 'POL 2114 Section 6',
      severity: 'HIGH',
      description: 'AI output could be discriminatory, offensive, or harmful to vulnerable communities.',
    });
    referrals.push({
      contact: KEY_CONTACTS.odi.contact,
      role: KEY_CONTACTS.odi.role,
      reason: 'Equality Impact Assessment required',
      email: KEY_CONTACTS.odi.email,
      phone: KEY_CONTACTS.odi.phone,
    });
    policyClauses.push('Section 6: Bias and Discrimination');
    policyClauses.push('NFRS Core Code of Ethics');
  }

  // Medium - Ethics alignment unclear
  if (responses.alignsWithEthics === 'no') {
    score += 30;
    risks.push({
      category: 'Ethical Use',
      clause: 'POL 2114 Section 6',
      severity: 'MEDIUM',
      description: 'AI use must align with NFRS Core Code of Ethics (Integrity, Respect, Professionalism, Accountability, Inclusivity).',
    });
    referrals.push({
      contact: KEY_CONTACTS.odi.contact,
      role: KEY_CONTACTS.odi.role,
      reason: 'Ethics review required',
      email: KEY_CONTACTS.odi.email,
      phone: KEY_CONTACTS.odi.phone,
    });
    policyClauses.push('Section 6: Ethical Use');
    policyClauses.push('NFRS Core Code of Ethics');
  }

  // Medium - Legal compliance unclear
  if (responses.compliesLegal === 'no') {
    score += 35;
    risks.push({
      category: 'Legal Compliance',
      clause: 'POL 2114 Section 10',
      severity: 'MEDIUM',
      description: 'AI use must comply with UK GDPR, Data Protection Act 2018, and relevant regulations.',
    });
    referrals.push({
      contact: KEY_CONTACTS.igo.contact,
      role: KEY_CONTACTS.igo.role,
      reason: 'Legal compliance review required',
      email: KEY_CONTACTS.igo.email,
      phone: KEY_CONTACTS.igo.phone,
    });
    policyClauses.push('Section 10: External Standards');
  }

  // Low - Disclosure
  if (responses.willDisclose === 'no') {
    score += 15;
    risks.push({
      category: 'Disclosure',
      clause: 'POL 2114 Section 7',
      severity: 'LOW',
      description: 'AI-generated content must be clearly identified as such.',
    });
    policyClauses.push('Section 7: Disclosure');
  } else if (responses.willDisclose === 'yes') {
    safeguards.push('Clear disclosure that content is AI-generated required');
  }

  // Standard safeguards for permitted use
  if (score < 40) {
    safeguards.push('Only use NFRS-approved AI tools (e.g., Microsoft Copilot M365)');
    safeguards.push('Do not input personal data, passwords, or security-critical information');
    safeguards.push('Maintain human judgment and professional expertise');
  }

  // Deduplicate policy clauses
  const uniqueClauses = Array.from(new Set(policyClauses));

  // Decision thresholds
  if (score >= 100) {
    return {
      outcome: 'PROHIBITED',
      risks,
      safeguards: [],
      referrals,
      policyClauses: uniqueClauses,
      explanation: 'This AI use violates POL 2114 and must not proceed. The task involves prohibited activities such as processing personal data in unapproved systems or exposing critical confidential information. Consider alternative approaches that do not involve AI, or consult with the relevant governance officers to redesign the workflow.',
    };
  }

  if (score >= 40) {
    return {
      outcome: 'REFER',
      risks,
      safeguards,
      referrals,
      policyClauses: uniqueClauses,
      explanation: 'This AI use requires approval and risk assessment before proceeding. Contact the listed officers to discuss appropriate safeguards, conduct necessary impact assessments (e.g., EQIA, DPIA), and obtain proper authorization. Do not proceed until you receive clearance.',
    };
  }

  return {
    outcome: 'PERMITTED',
    risks,
    safeguards,
    referrals,
    policyClauses: uniqueClauses,
    explanation: 'This AI use appears compliant with POL 2114, subject to the safeguards listed below. You may proceed, but you remain personally accountable for verifying all AI outputs and ensuring compliance with NFRS policies and values.',
  };
}
