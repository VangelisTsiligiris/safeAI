import jsPDF from 'jspdf';

const NFRS_RED = '#C8102E';
const NFRS_GREY = '#333333';
const PAGE_WIDTH = 210; // A4 width in mm
const PAGE_HEIGHT = 297; // A4 height in mm
const MARGIN = 20;
const CONTENT_WIDTH = PAGE_WIDTH - (MARGIN * 2);

export interface PDFExportOptions {
  title: string;
  subtitle?: string;
  sections: {
    heading: string;
    content: string | string[];
  }[];
  footer?: string;
}

interface SectionContent {
  heading: string;
  content: string | string[];
}

function addNFRSHeader(doc: jsPDF, title: string, subtitle?: string) {
  // NFRS branding header
  doc.setFillColor(NFRS_RED);
  doc.rect(0, 0, PAGE_WIDTH, 15, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('NFRS AI Toolkit', MARGIN, 10);
  
  // Main title
  doc.setTextColor(NFRS_GREY);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text(title, MARGIN, 30);
  
  if (subtitle) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    doc.text(subtitle, MARGIN, 38);
  }
  
  return subtitle ? 45 : 38;
}

function addNFRSFooter(doc: jsPDF, pageNumber: number, totalPages: number, footerText?: string) {
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.setFont('helvetica', 'normal');
  
  if (footerText) {
    doc.text(footerText, MARGIN, PAGE_HEIGHT - 15);
  }
  
  doc.text(
    `Page ${pageNumber} of ${totalPages}`,
    PAGE_WIDTH - MARGIN,
    PAGE_HEIGHT - 10,
    { align: 'right' }
  );
  
  doc.text(
    `© ${new Date().getFullYear()} Nottinghamshire Fire & Rescue Service`,
    MARGIN,
    PAGE_HEIGHT - 10
  );
}

function splitTextToLines(doc: jsPDF, text: string, maxWidth: number): string[] {
  return doc.splitTextToSize(text, maxWidth);
}

export function generateWorkshopPDF(options: PDFExportOptions): void {
  const doc = new jsPDF();
  let yPosition = addNFRSHeader(doc, options.title, options.subtitle);
  yPosition += 10;
  
  options.sections.forEach((section, sectionIndex) => {
    // Check if we need a new page
    if (yPosition > PAGE_HEIGHT - 40) {
      doc.addPage();
      yPosition = addNFRSHeader(doc, options.title, options.subtitle);
      yPosition += 10;
    }
    
    // Section heading
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(NFRS_RED);
    doc.text(section.heading, MARGIN, yPosition);
    yPosition += 8;
    
    // Section content
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(NFRS_GREY);
    
    const content = Array.isArray(section.content) ? section.content : [section.content];
    
    content.forEach((paragraph) => {
      const lines = splitTextToLines(doc, paragraph, CONTENT_WIDTH);
      lines.forEach((line) => {
        if (yPosition > PAGE_HEIGHT - 30) {
          doc.addPage();
          yPosition = addNFRSHeader(doc, options.title, options.subtitle);
          yPosition += 10;
        }
        doc.text(line, MARGIN, yPosition);
        yPosition += 5;
      });
      yPosition += 3; // Extra space between paragraphs
    });
    
    yPosition += 5; // Extra space after section
  });
  
  // Add footers to all pages with correct total pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    addNFRSFooter(doc, i, totalPages, options.footer);
  }
  
  // Generate filename
  const filename = `NFRS_${options.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(filename);
}

export function exportFundamentals(content: { 
  title: string; 
  text: string; 
  examples?: string[];
}[], keyTakeaways?: string[]): void {
  const sections: SectionContent[] = content.flatMap(item => {
    const itemSections: SectionContent[] = [
      {
        heading: item.title,
        content: item.text,
      }
    ];
    
    // Add examples if they exist
    if (item.examples && item.examples.length > 0) {
      itemSections.push({
        heading: 'Fire Service Examples:',
        content: item.examples.map((ex, idx) => `• ${ex}`),
      });
    }
    
    return itemSections;
  });
  
  // Add Key Takeaways section if provided
  if (keyTakeaways && keyTakeaways.length > 0) {
    sections.push({
      heading: 'Key Takeaways',
      content: keyTakeaways.map(takeaway => `✓ ${takeaway}`),
    });
  }
  
  generateWorkshopPDF({
    title: 'AI Fundamentals for Fire Services',
    subtitle: 'Workshop Module 1',
    sections,
    footer: 'POL 2114 - Artificial Intelligence Policy',
  });
}

export function exportRisksAndEthics(content: { 
  title: string; 
  text: string; 
  examples?: string[];
}[], keyTakeaways?: string[]): void {
  const sections: SectionContent[] = content.flatMap(item => {
    const itemSections: SectionContent[] = [
      {
        heading: item.title,
        content: item.text,
      }
    ];
    
    // Add examples if they exist
    if (item.examples && item.examples.length > 0) {
      itemSections.push({
        heading: 'Fire Service Examples:',
        content: item.examples.map((ex, idx) => `• ${ex}`),
      });
    }
    
    return itemSections;
  });
  
  // Add Key Takeaways section if provided
  if (keyTakeaways && keyTakeaways.length > 0) {
    sections.push({
      heading: 'Key Takeaways',
      content: keyTakeaways.map(takeaway => `✓ ${takeaway}`),
    });
  }
  
  generateWorkshopPDF({
    title: 'Risk & Ethics Framework',
    subtitle: 'Workshop Module 2',
    sections,
    footer: 'POL 2114 - Artificial Intelligence Policy | NFRS Core Code of Ethics',
  });
}

export function exportScenarios(
  scenarios: Array<{
    title: string;
    context: string;
    responses: {
      risks: string;
      policyClauses: string;
      safeguards: string;
      recommendation: string;
      notes: string;
    };
  }>
): void {
  const sections = scenarios.flatMap((scenario, index) => [
    {
      heading: `Scenario ${index + 1}: ${scenario.title}`,
      content: scenario.context,
    },
    {
      heading: 'Group Discussion - Identified Risks',
      content: scenario.responses.risks || 'No response recorded',
    },
    {
      heading: 'Group Discussion - Policy Clauses',
      content: scenario.responses.policyClauses || 'No response recorded',
    },
    {
      heading: 'Group Discussion - Safeguards',
      content: scenario.responses.safeguards || 'No response recorded',
    },
    {
      heading: 'Group Discussion - Recommendation',
      content: scenario.responses.recommendation || 'No response recorded',
    },
    {
      heading: 'Additional Notes',
      content: scenario.responses.notes || 'No notes',
    },
  ]);
  
  generateWorkshopPDF({
    title: 'Interactive Scenarios',
    subtitle: 'Workshop Module 3 - Group Responses',
    sections,
    footer: 'POL 2114 - Artificial Intelligence Policy',
  });
}

export function exportActionPlan(actionPlan: {
  department: string;
  priorities: string[];
  timeline: string;
  responsibilities: string;
  resources: string;
  successMetrics: string;
}): void {
  const sections = [
    {
      heading: 'Department',
      content: actionPlan.department || 'Not specified',
    },
    {
      heading: 'AI Governance Priorities',
      content: actionPlan.priorities.length > 0 
        ? actionPlan.priorities.map((p, i) => `${i + 1}. ${p}`).join('\n')
        : 'No priorities defined',
    },
    {
      heading: 'Implementation Timeline',
      content: actionPlan.timeline || 'Not specified',
    },
    {
      heading: 'Roles & Responsibilities',
      content: actionPlan.responsibilities || 'Not specified',
    },
    {
      heading: 'Required Resources',
      content: actionPlan.resources || 'Not specified',
    },
    {
      heading: 'Success Metrics',
      content: actionPlan.successMetrics || 'Not specified',
    },
  ];
  
  generateWorkshopPDF({
    title: 'Departmental Action Plan',
    subtitle: 'Workshop Module 4 - AI Governance Implementation',
    sections,
    footer: 'POL 2114 - Artificial Intelligence Policy | Annual Delivery Plan 2025-26',
  });
}
