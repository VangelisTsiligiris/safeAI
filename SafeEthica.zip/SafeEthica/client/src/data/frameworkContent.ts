export interface ContentSection {
  id: string;
  title: string;
  subsections: {
    heading: string;
    content: string;
    examples?: string[];
  }[];
}

export const AI_FUNDAMENTALS: ContentSection = {
  id: 'ai-fundamentals',
  title: 'AI Fundamentals for Fire Services',
  subsections: [
    {
      heading: 'What is Artificial Intelligence?',
      content: 'Artificial Intelligence (AI) refers to computer systems that can perform tasks typically requiring human intelligence, such as learning from data, recognizing patterns, making predictions, and generating content. In fire and rescue services, AI can support decision-making, improve efficiency, and enhance service delivery - but only when used responsibly and in compliance with policy.',
    },
    {
      heading: 'Analytical AI',
      content: 'Analytical AI uses historical data and statistical models to identify patterns, make predictions, and support decision-making. These systems analyze large datasets to uncover insights that might not be obvious to human analysts.',
      examples: [
        'Risk modeling: Predicting fire risk in different geographical areas based on building types, demographics, and historical incident data',
        'Incident prediction: Forecasting demand patterns to optimize crew deployment and resource allocation',
        'Resource optimization: Analyzing response times and incident patterns to inform station locations and vehicle placement',
        'CFRMIS data analysis: Identifying trends in incident types, causes, and outcomes to inform prevention strategies',
        'Performance analytics: Evaluating service delivery metrics and operational efficiency across different teams and time periods',
      ],
    },
    {
      heading: 'Generative AI',
      content: 'Generative AI creates new content - text, images, code, or other outputs - based on patterns learned from training data. Tools like ChatGPT, Microsoft Copilot, and similar systems can draft documents, summarize information, answer questions, and assist with content creation. While powerful, these tools require careful oversight due to risks of inaccuracy and bias.',
      examples: [
        'ChatGPT and Microsoft Copilot: Drafting emails, reports, policy documents, and public communications',
        'Summarization tools: Condensing lengthy documents, meeting notes, or research reports into key points',
        'Content creation for training materials: Generating draft presentations, scenario exercises, or learning resources',
        'Translation services: Converting documents between languages for diverse communities',
        'Code generation: Assisting with software development and automation scripts (with expert review)',
      ],
    },
    {
      heading: 'Machine Learning',
      content: 'Machine Learning is a subset of AI where systems improve their performance by learning from data without being explicitly programmed. As more data is processed, the system refines its predictions or classifications. In fire services, this can support pattern recognition and predictive modeling.',
      examples: [
        'Pattern recognition in historical incident data: Identifying common factors in fire deaths or serious injuries',
        'False alarm prediction: Analyzing building types, times, and other factors to predict false alarm risks',
        'Equipment failure prediction: Using sensor data to predict when vehicles or equipment may need maintenance',
        'Call categorization: Automatically classifying emergency calls by type and severity to support dispatch decisions',
      ],
    },
    {
      heading: 'Deep Learning and Advanced AI',
      content: 'Deep Learning uses neural networks with multiple layers to process complex data like images, video, and speech. These systems can achieve human-level or better performance in specific narrow tasks. However, POL 2114 imposes restrictions on certain advanced AI applications due to ethical and legal concerns.',
      examples: [
        'Image recognition: Analyzing fire scene photos to identify hazards, building construction types, or equipment (with caution per POL 2114 prohibitions on facial recognition)',
        'Speech recognition: Transcribing incident debriefs, interviews, or emergency calls for analysis',
        'Thermal imaging analysis: Identifying heat signatures in complex fire scenes to support operational decisions',
      ],
    },
    {
      heading: 'Key NFRS Use Cases from Annual Delivery Plan 2025-26',
      content: 'NFRS is exploring AI applications aligned with our strategic goals of Prevention, Protection, Response, and continuous improvement. These use cases must comply with POL 2114 and support our mission of safer communities.',
      examples: [
        'CFRMIS improvements: Using data analytics to improve incident recording, performance reporting, and strategic planning',
        'Data-driven service delivery: Analyzing incident and demographic data to target prevention resources effectively',
        'Operational intelligence: Synthesizing information from multiple sources to support risk-based planning',
        'Efficiency automation: Streamlining administrative tasks to free up time for frontline service delivery',
        'Digital maturity: Enhancing digital tools and systems to improve staff productivity and public engagement',
      ],
    },
    {
      heading: 'Understanding AI Limitations',
      content: 'AI systems have inherent limitations that users must understand to apply them appropriately. They operate within narrow domains, lack genuine understanding or common sense, and cannot replicate human judgment in complex or novel situations.',
      examples: [
        'Narrow scope: AI trained to categorize incident types cannot give operational tactical advice beyond its training data',
        'No contextual awareness: AI drafting public communications has no understanding of local community sensitivities or current political contexts',
        'Cannot handle exceptions: AI prediction models trained on typical scenarios may fail completely when faced with unprecedented situations',
        'No moral reasoning: AI cannot make value judgments or ethical decisions - it only identifies statistical patterns in data',
        'Practical Guidance: Always apply human expertise, local knowledge, and professional judgment alongside AI tools. Use AI to augment your capabilities, not replace them.',
      ],
    },
    {
      heading: 'AI Literacy for Fire Service Professionals',
      content: 'Developing basic AI literacy across NFRS enables staff to use AI tools safely and effectively while maintaining professional standards. This includes understanding how AI systems work, recognizing their outputs, and knowing when to question or verify information.',
      examples: [
        'Prompt engineering skills: Learning to craft clear, specific instructions to get better results from generative AI tools',
        'Output verification: Developing techniques to check AI-generated content for accuracy, bias, and appropriateness',
        'Tool selection: Understanding which AI tool is appropriate for different tasks (e.g., approved vs. unapproved, cloud vs. local)',
        'Risk awareness: Recognizing situations where AI use would be inappropriate or prohibited under POL 2114',
        'Continuous learning: Staying informed about new AI capabilities, risks, and best practices through ongoing training and guidance',
      ],
    },
  ],
};

export const RISK_ETHICS_FRAMEWORK: ContentSection = {
  id: 'risk-ethics',
  title: 'Risk & Ethics Framework',
  subsections: [
    {
      heading: 'Hallucination & Accuracy Failures',
      content: 'AI systems, especially generative models like ChatGPT, can "hallucinate" - confidently producing false or invented information that appears plausible. This poses serious risks in fire services where accuracy is life-critical.',
      examples: [
        'Fire Service Example: AI invents a non-existent fire safety regulation in a public communication, leading to confusion or non-compliance',
        'Fire Service Example: AI generates incorrect evacuation procedures that could endanger lives during an emergency',
        'Fire Service Example: AI fabricates statistics or incident details in a report submitted to the Fire Authority',
        'Policy Control: POL 2114 Section 6 (Accuracy) mandates human review and verification of all AI outputs before use. Users remain accountable for any content produced with AI assistance.',
      ],
    },
    {
      heading: 'Algorithmic Bias & Discrimination',
      content: 'AI systems learn patterns from historical data, which may reflect past biases or inequalities. When deployed in fire services, biased AI could perpetuate discrimination against vulnerable communities, violating our Core Code of Ethics and equality duties.',
      examples: [
        'Fire Service Example: AI trained on historical Safe & Well visit data deprioritizes certain postcodes or demographics, reducing service to communities who need it most',
        'Fire Service Example: Recruitment AI filters out qualified candidates based on protected characteristics embedded in historical hiring patterns',
        'Fire Service Example: Risk prediction models unfairly classify certain neighborhoods as "low priority" based on biased assumptions',
        'Policy Control: POL 2114 Section 6 (Bias and Discrimination) requires assessment of AI for potential bias. NFRS Core Code of Ethics demands fairness, respect, and equality in all service delivery.',
      ],
    },
    {
      heading: 'Data Sovereignty & Confidentiality Breaches',
      content: 'Many AI tools process data on external servers, potentially outside UK jurisdiction. Entering confidential, personal, or operationally sensitive data into unapproved AI systems risks breaches of GDPR, data protection law, and public trust.',
      examples: [
        'Fire Service Example: Personal details from a vulnerable person referral (name, address, health conditions) entered into ChatGPT, exposing data to third parties',
        'Fire Service Example: Confidential business fire safety audit reports uploaded to an AI summarization tool, breaching commercial confidentiality',
        'Fire Service Example: Operational plans for a major incident shared with AI for scenario planning, risking security leaks',
        'Policy Control: POL 2114 Section 8 (Prohibited Use) strictly forbids entering personal data, confidential information, or security-sensitive material into unapproved AI systems. Only approved tools with appropriate data residency (e.g., Microsoft Copilot M365) may process sensitive data, and only with proper safeguards.',
      ],
    },
    {
      heading: 'Public Trust Erosion',
      content: 'Fire and rescue services are among the most trusted public institutions. Use of AI in ways perceived as opaque, unfair, or unsafe could damage this trust, particularly if it leads to visible failures or perceived dehumanization of services.',
      examples: [
        'Fire Service Example: Inaccurate AI-generated safety advice shared on social media during an incident, leading to public criticism and loss of credibility',
        'Fire Service Example: Public learns that Safe & Well prioritization decisions are made by an algorithm rather than human judgment, raising concerns about care and compassion',
        'Fire Service Example: AI-generated responses to public inquiries feel impersonal or fail to address individual circumstances appropriately',
        'Policy Control: POL 2114 Section 6 (Ethical Use) and Section 7 (Disclosure) require AI use to align with NFRS values and for AI-generated content to be clearly identified. Public trust must be protected through transparency and accountability.',
      ],
    },
    {
      heading: 'Automation Complacency & Loss of Human Judgment',
      content: 'Over-reliance on AI tools can lead to "automation bias" - where humans uncritically accept AI outputs without proper scrutiny. In fire services, this could undermine professional judgment and situational awareness, particularly in dynamic operational environments.',
      examples: [
        'Fire Service Example: Incident commanders defer to AI-generated tactical recommendations without applying contextual knowledge, missing critical local factors',
        'Fire Service Example: Staff stop developing core skills (e.g., data analysis, report writing) because "AI does it faster," leading to capability loss',
        'Fire Service Example: Firefighters trust AI risk assessments without conducting their own dynamic risk assessment on scene',
        'Policy Control: POL 2114 Section 6 (Accuracy and Accountability) emphasizes that humans remain responsible for decisions. AI is a tool to support, not replace, professional expertise and judgment.',
      ],
    },
    {
      heading: 'Copyright & Intellectual Property Infringement',
      content: 'AI systems trained on vast internet datasets may inadvertently reproduce copyrighted material. Content generated by AI could infringe on others\' intellectual property rights, exposing NFRS to legal and reputational risks.',
      examples: [
        'Fire Service Example: AI generates training materials that plagiarize content from other fire services or commercial training providers',
        'Fire Service Example: AI-created graphics or presentations contain elements copied from copyrighted sources without attribution',
        'Fire Service Example: Code generated by AI includes proprietary algorithms from licensed software',
        'Policy Control: POL 2114 Section 6 (Copyright and Intellectual Property) requires users to ensure AI-generated content does not infringe IP rights. All outputs must be reviewed for originality and proper attribution.',
      ],
    },
    {
      heading: 'Practical Risk Mitigation Strategies',
      content: 'While AI carries risks, these can be substantially mitigated through appropriate safeguards, governance, and user behaviors. Understanding and applying these strategies enables beneficial AI use while protecting against harms.',
      examples: [
        'Human-in-the-loop verification: Never publish or action AI outputs without competent human review. Treat AI as a draft, not a final product.',
        'Red-teaming and testing: Before deploying AI tools in operational contexts, test them with challenging scenarios to identify failure modes.',
        'Transparency and disclosure: Clearly label AI-generated content and explain to stakeholders when and how AI has been used in decision-making.',
        'Tiered approval processes: Implement escalation for high-stakes AI use cases (e.g., public communications, policy decisions, vulnerable person services).',
        'Ongoing monitoring: Regularly review AI tools and outputs for emerging issues, bias, or degraded performance over time.',
        'Training and competence: Ensure staff using AI tools receive appropriate training on capabilities, limitations, and organizational policy requirements.',
      ],
    },
    {
      heading: 'NFRS Core Code of Ethics in AI Use',
      content: 'The NFRS Core Code of Ethics applies to all aspects of our work, including AI use. These principles guide responsible decision-making and ensure AI supports our values of public service, integrity, and professionalism.',
      examples: [
        'Integrity: Be honest about AI limitations. Do not claim AI outputs as your own original work. Disclose AI use appropriately.',
        'Respect: Ensure AI does not perpetuate discrimination or bias. Treat all members of the community with fairness and dignity, including in AI-assisted decisions.',
        'Professionalism: Maintain professional standards when using AI. Do not use AI to circumvent proper processes or avoid due diligence.',
        'Public Service: Use AI in ways that genuinely serve the public interest. Prioritize public safety, wellbeing, and trust over speed or convenience.',
        'Accountability: Accept responsibility for AI-assisted work. Do not blame AI for errors - you remain accountable for outputs you create or approve.',
      ],
    },
  ],
};
