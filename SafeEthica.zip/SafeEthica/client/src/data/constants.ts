// NFRS Departments
export const DEPARTMENTS = [
  { value: 'community-safety', label: 'Community Safety & Engagement' },
  { value: 'fire-protection', label: 'Fire Protection' },
  { value: 'response', label: 'Response (Wholetime/On-call/JFC)' },
  { value: 'pod', label: 'People & Organisational Development' },
  { value: 'strategic-support', label: 'Strategic Support' },
  { value: 'resources', label: 'Resources (ICT, Estates, Engineering, Procurement)' },
  { value: 'finance', label: 'Financial Services' },
] as const;

// NFRS Key Contacts (from POL 2114 Section 5)
export const KEY_CONTACTS = {
  igo: {
    role: 'Information Governance Officer',
    contact: 'Information Governance Officer (IGO)',
    email: 'dataprotection@notts-fire.gov.uk',
    phone: '0115 967 0880',
    responsibilities: ['Data protection concerns', 'GDPR compliance', 'Personal data handling']
  },
  ictSecurity: {
    role: 'ICT Security Manager',
    contact: 'ICT Security Manager',
    email: 'ictsecurity@notts-fire.gov.uk',
    phone: '0115 967 0880',
    responsibilities: ['Cyber security assessment', 'Tool certification', 'Security standards']
  },
  odi: {
    role: 'Organisational Development and Inclusion Manager',
    contact: 'Organisational Development and Inclusion Manager',
    email: 'odi@notts-fire.gov.uk',
    phone: '0115 967 0880',
    responsibilities: ['Ethics concerns', 'Equality Impact Assessments', 'Bias and discrimination']
  }
} as const;

// AI Tool Options
export const AI_TOOLS = [
  { value: 'microsoft-copilot', label: 'Microsoft Copilot' },
  { value: 'chatgpt', label: 'ChatGPT' },
  { value: 'other', label: 'Other (please specify)' },
] as const;

// Purpose Options
export const AI_PURPOSES = [
  { value: 'research', label: 'Research / Information Gathering' },
  { value: 'summarization', label: 'Summarization / Document Analysis' },
  { value: 'content-creation', label: 'Content Creation / Writing' },
  { value: 'data-analysis', label: 'Data Analysis / Pattern Recognition' },
  { value: 'translation', label: 'Translation / Language Support' },
  { value: 'other', label: 'Other' },
] as const;

// Governance Touchpoints
export const GOVERNANCE_TOUCHPOINTS = [
  'Information Governance Officer (IGO)',
  'ICT Security Manager',
  'Organisational Development and Inclusion Manager',
  'Data Protection Officer',
  'Health & Safety Team',
  'Legal Services',
  'Communications Team',
  'Line Manager',
] as const;

// Related Policies (POL 2114 Section 11)
export const RELATED_POLICIES = [
  { code: 'POL 3004', title: 'Data Protection Policy' },
  { code: 'POL 2084', title: 'Internet Acceptable Use Policy' },
  { code: 'POL 2090', title: 'IT Information Security Policy' },
] as const;

// Outcome Colors
export const OUTCOME_STYLES = {
  PERMITTED: {
    bg: 'bg-green-50',
    border: 'border-green-500',
    text: 'text-green-900',
    badge: 'bg-green-500 text-white',
    icon: 'text-green-500',
  },
  REFER: {
    bg: 'bg-amber-50',
    border: 'border-amber-500',
    text: 'text-amber-900',
    badge: 'bg-amber-500 text-white',
    icon: 'text-amber-500',
  },
  PROHIBITED: {
    bg: 'bg-red-50',
    border: 'border-red-600',
    text: 'text-red-900',
    badge: 'bg-red-600 text-white',
    icon: 'text-red-600',
  },
} as const;
