export interface PolicyClause {
  section: string;
  title: string;
  summary: string;
  keyPoints: string[];
}

export const POLICY_EXCERPTS: PolicyClause[] = [
  {
    section: 'Section 5',
    title: 'Roles and Responsibilities',
    summary: 'Defines key governance roles for AI use at NFRS, including oversight and accountability structures.',
    keyPoints: [
      'Information Governance Officer (IGO): Data protection and GDPR compliance',
      'ICT Security Manager: Cyber security assessment and tool certification',
      'Organisational Development and Inclusion Manager: Ethics and equality impact',
      'All staff: Responsible for understanding and complying with this policy',
      'Line managers: Must ensure teams receive appropriate AI guidance and training',
    ],
  },
  {
    section: 'Section 6',
    title: 'Use of AI - Responsibilities',
    summary: 'Sets out mandatory requirements for responsible AI use, covering accuracy, bias, confidentiality, accountability, and ethical considerations.',
    keyPoints: [
      'Accuracy: All AI outputs must be reviewed and verified by a competent human before use',
      'Bias and Discrimination: Users must consider whether AI outputs could be discriminatory or unfair',
      'Confidentiality: Sensitive or confidential information must not be disclosed to unauthorized AI systems',
      'Accountability: Individuals remain responsible for content produced with AI assistance',
      'Cyber Security: Only use AI tools approved by ICT that meet NFRS security standards',
      'Copyright and Intellectual Property: Ensure AI-generated content does not infringe IP rights',
      'Ethical Use: AI must align with NFRS Core Code of Ethics and public service values',
    ],
  },
  {
    section: 'Section 7',
    title: 'Permitted Use of AI',
    summary: 'Describes circumstances where AI use is allowed, subject to safeguards and compliance with Section 6 requirements.',
    keyPoints: [
      'AI may be used for research, information gathering, and learning',
      'AI may assist with drafting documents, presentations, and communications (with human review)',
      'AI may support data analysis and pattern recognition (with appropriate data handling)',
      'All permitted use must include human oversight and verification',
      'AI-generated content must be clearly identified as such (disclosure requirement)',
      'Users must ensure compliance with GDPR, data protection law, and confidentiality obligations',
    ],
  },
  {
    section: 'Section 8',
    title: 'Prohibited Use of AI',
    summary: 'Explicitly bans certain AI applications that pose unacceptable risks to data protection, security, or public trust.',
    keyPoints: [
      'Personal data (names, addresses, health information) must not be entered into unapproved AI systems',
      'Operationally sensitive or confidential information must not be processed by external AI tools',
      'Security-critical data (passwords, access codes, infrastructure details) must never be shared with AI',
      'AI must not be used for automated decision-making affecting individuals\' rights without human oversight',
      'Facial recognition and biometric processing are prohibited without explicit approval and legal basis',
      'AI-generated content must not be presented as human-authored without disclosure',
    ],
  },
  {
    section: 'Section 10',
    title: 'External Standards and Frameworks',
    summary: 'References national and international standards that NFRS AI use must comply with.',
    keyPoints: [
      'UK GDPR and Data Protection Act 2018',
      'ISO 27001 Information Security Management',
      'NCSC Cyber Security Guidance',
      'Fire and Rescue National Framework',
      'Equality Act 2010',
      'Human Rights Act 1998',
      'Public Sector Equality Duty',
    ],
  },
  {
    section: 'Section 11',
    title: 'Related NFRS Policies',
    summary: 'Identifies other NFRS policies that intersect with AI use and must be followed alongside POL 2114.',
    keyPoints: [
      'POL 3004 - Data Protection Policy',
      'POL 2084 - Internet Acceptable Use Policy',
      'POL 2090 - IT Information Security Policy',
      'NFRS Core Code of Ethics',
      'Information Security Policies and Procedures',
    ],
  },
];

export const NFRS_CORE_CODE = {
  title: 'NFRS Core Code of Ethics',
  values: [
    {
      value: 'Integrity',
      description: 'We are honest, open, and transparent in all we do',
    },
    {
      value: 'Respect',
      description: 'We treat everyone with dignity and fairness',
    },
    {
      value: 'Professionalism',
      description: 'We deliver high-quality services with competence and care',
    },
    {
      value: 'Accountability',
      description: 'We take responsibility for our actions and decisions',
    },
    {
      value: 'Inclusivity',
      description: 'We value diversity and promote equality',
    },
  ],
  relevanceToAI: 'All AI use must align with these core values. Any AI application that conflicts with integrity, respect, professionalism, accountability, or inclusivity should be reconsidered or redesigned.',
};
