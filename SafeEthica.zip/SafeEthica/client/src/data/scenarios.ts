export interface Scenario {
  id: string;
  title: string;
  context: string;
  stakeholders: string[];
  aiInvolvement: string;
  prompts: {
    risks: string;
    policyClauses: string;
    safeguards: string;
    recommendation: string;
  };
  // facilitatorNotes removed - fetched from admin-only backend endpoint
}

export const SCENARIOS: Scenario[] = [
  {
    id: 'scenario-1',
    title: 'GenAI for Public Communications During Major Incident',
    context: `During a major wildfire incident affecting rural Nottinghamshire, the Communications Team is under pressure to provide rapid updates to the public via social media and the NFRS website. A team member proposes using ChatGPT to draft public safety messages, evacuation guidance, and FAQs about air quality and property protection.

The incident is evolving quickly, with changing wind patterns and new areas being threatened. Traditional communications processes involve multiple approvals and can take 30-45 minutes per update. The AI tool could reduce this to 5-10 minutes, potentially saving lives through faster warnings.

However, accuracy is critical. Incorrect evacuation routes, overstated risks, or outdated information could cause public harm or panic. The AI has no real-time access to incident data and relies on the operator's text prompts.`,
    stakeholders: [
      'Public in affected areas',
      'Operational crews managing the incident',
      'Media and partner agencies',
      'NFRS Communications Team',
    ],
    aiInvolvement: 'Using ChatGPT to generate public safety messages, social media posts, and FAQ responses during an active emergency incident.',
    prompts: {
      risks: 'What are the key risks of using AI for emergency communications?',
      policyClauses: 'Which sections of POL 2114 are most relevant to this scenario?',
      safeguards: 'What safeguards would be needed to make this use case safer?',
      recommendation: 'Would you PERMIT (with conditions), REFER for assessment, or PROHIBIT this use of AI?',
    },
  },
  {
    id: 'scenario-2',
    title: 'AI-Assisted Prioritization of Safe & Well Visits',
    context: `The Community Safety Team receives approximately 800 Safe & Well Visit referrals per month from partner agencies (NHS, social services, police). These referrals identify vulnerable individuals who would benefit from fire safety advice, smoke alarm installation, and home hazard assessments.

Current prioritization is manual, based on practitioner judgment considering factors like age, mobility, medical conditions, previous fire incidents, and housing type. A team member suggests using an AI tool to analyze referral data and automatically prioritize visits based on risk scoring.

The AI would process data including: names, addresses, ages, medical conditions (e.g., dementia, oxygen use), property types, postcode-level deprivation indices, and past incident history. It would assign each referral a risk score (1-10) to help allocate limited crew time to highest-need individuals.`,
    stakeholders: [
      'Vulnerable residents awaiting visits',
      'Partner agencies making referrals',
      'Safe & Well practitioners',
      'Community Safety management team',
    ],
    aiInvolvement: 'AI tool processing personal and medical data to automatically prioritize home safety visits for vulnerable persons.',
    prompts: {
      risks: 'What data protection, bias, and ethical concerns arise from this use case?',
      policyClauses: 'How does this align (or conflict) with POL 2114 requirements?',
      safeguards: 'What safeguards or alternative approaches should be considered?',
      recommendation: 'Would you PERMIT, REFER, or PROHIBIT this AI application?',
    },
  },
  {
    id: 'scenario-3',
    title: 'Summarizing Operational Intelligence Briefings',
    context: `The Strategic Intelligence Team produces weekly operational intelligence briefings consolidating data from multiple sources: incident reports, CFRMIS data, partner agency alerts (police, ambulance), weather forecasts, and risk assessments. These briefings inform resource deployment and prevention strategies.

Each briefing is 15-20 pages and takes 6-8 hours to compile manually. An analyst proposes using Microsoft Copilot to summarize key documents, identify trends, and draft the weekly summary. This could reduce production time to 2-3 hours, allowing more frequent updates.

The source documents include: incident addresses (sometimes with names), commercially sensitive information about business premises, ongoing criminal investigations, and confidential risk assessments for high-risk individuals (e.g., vulnerable adults with hoarding behaviors).`,
    stakeholders: [
      'Operational commanders making deployment decisions',
      'Prevention teams planning interventions',
      'Partner agencies sharing confidential data',
      'Strategic management team',
    ],
    aiInvolvement: 'Using Microsoft Copilot to summarize and synthesize operational intelligence documents containing sensitive and confidential information.',
    prompts: {
      risks: 'What confidentiality and security risks exist in this scenario?',
      policyClauses: 'What conditions must be met for this use to comply with POL 2114?',
      safeguards: 'How could this workflow be redesigned to reduce risk while gaining efficiency?',
      recommendation: 'PERMIT, REFER, or PROHIBIT - and under what conditions?',
    },
  },
  {
    id: 'scenario-4',
    title: 'AI-Generated Training Content for Firefighter Competency',
    context: `The Training & Development Team is updating the Breathing Apparatus (BA) training program to reflect new equipment and updated national guidance. Creating training materials (presentations, handouts, assessment questions, scenario exercises) typically takes 3-4 weeks per module.

A trainer proposes using ChatGPT to generate draft training content, including:
- PowerPoint slide text and presenter notes
- Practical scenario descriptions for skills assessment
- Multiple-choice questions for knowledge checks
- Safety briefings and risk assessments

The AI would be prompted with existing training manuals, equipment specifications, and national operational guidance documents. The trainer would review and refine all outputs before use. The goal is to reduce development time to 1 week, allowing faster rollout of critical safety training.`,
    stakeholders: [
      'Firefighters receiving training',
      'Training instructors delivering content',
      'Operational crews relying on competent BA operators',
      'Public safety (dependence on properly trained responders)',
    ],
    aiInvolvement: 'ChatGPT generating draft training materials for life-critical firefighter skills based on existing technical documentation.',
    prompts: {
      risks: 'What accuracy, copyright, and accountability concerns apply here?',
      policyClauses: 'Which POL 2114 requirements are most critical for this use case?',
      safeguards: 'What review and validation processes would be essential?',
      recommendation: 'Under what conditions (if any) should this be PERMITTED?',
    },
  },
];
