import { useEffect, useState } from "react";
import { Link, useSearch } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertTriangle, XCircle, Download, Home, Phone, Mail, Loader2, ArrowLeft } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { Badge } from "@/components/ui/badge";
import type { AssessmentResponses, ComplianceDecision } from "@shared/schema";
import { OUTCOME_STYLES } from "@/data/constants";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { generateComplianceResultPDF } from "@/utils/pdfGenerator";

export default function Result() {
  const search = useSearch();
  const params = new URLSearchParams(search);

  const department = params.get('dept') || '';
  const task = params.get('task') || '';
  const tool = params.get('tool') || '';
  const purpose = params.get('purpose') || '';
  const responsesJson = params.get('responses') || '{}';

  const [responses, setResponses] = useState<AssessmentResponses>({} as AssessmentResponses);
  const [decision, setDecision] = useState<ComplianceDecision | null>(null);
  const [hasInvalidData, setHasInvalidData] = useState(false);

  // Parse URL parameters on mount
  useEffect(() => {
    try {
      const parsed = JSON.parse(decodeURIComponent(responsesJson)) as AssessmentResponses;
      
      // Check if we have valid responses
      if (Object.keys(parsed).length === 0 || !department || !task) {
        setHasInvalidData(true);
        return;
      }
      
      setResponses(parsed);
    } catch (error) {
      console.error('Failed to parse responses:', error);
      setHasInvalidData(true);
    }
  }, [responsesJson, department, task]);

  // Use backend API for compliance assessment via React Query mutation
  const assessmentMutation = useMutation({
    mutationFn: async (assessmentData: {
      department: string;
      taskDescription: string;
      aiTool: string;
      purpose: string;
      responses: AssessmentResponses;
    }) => {
      const res = await apiRequest('POST', '/api/compliance/assess', assessmentData);
      const result = await res.json() as ComplianceDecision;
      return { result, assessmentData };
    },
    onSuccess: ({ result, assessmentData }) => {
      setDecision(result);
      
      // Save assessment to backend storage
      apiRequest('POST', '/api/compliance/assessments', {
        ...assessmentData,
        outcome: result.outcome,
        safeguards: result.safeguards,
        referrals: result.referrals,
        risks: result.risks,
      }).catch(err => console.error('Failed to save assessment:', err));
    },
    onError: (error) => {
      console.error('Assessment failed:', error);
    }
  });

  // Trigger assessment when responses are loaded (but not after errors)
  useEffect(() => {
    if (Object.keys(responses).length > 0 && !decision && !assessmentMutation.isPending && !assessmentMutation.isError) {
      assessmentMutation.mutate({
        department,
        taskDescription: task,
        aiTool: tool,
        purpose,
        responses,
      });
    }
  }, [responses, department, task, tool, purpose, decision, assessmentMutation.isPending, assessmentMutation.isError]);

  const handleExport = () => {
    if (decision) {
      generateComplianceResultPDF(department, task, tool, purpose, decision);
    }
  };

  // Invalid/missing data state - check FIRST
  if (hasInvalidData) {
    return (
      <div className="min-h-screen bg-background">
        <Header title="Assessment Result" subtitle="Step 3 of 3" />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <Card>
            <CardContent className="py-8">
              <div className="flex items-center gap-3 text-destructive mb-4">
                <XCircle className="h-6 w-6" data-testid="icon-invalid-data" />
                <h3 className="text-lg font-semibold">Invalid Assessment Data</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                The assessment data is missing or invalid. This usually happens when accessing this page directly or after a session timeout.
              </p>
              <p className="text-muted-foreground mb-6">
                Please start a new compliance assessment from the beginning.
              </p>
              <Link href="/compliance">
                <Button data-testid="button-start-new-assessment">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Start New Assessment
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Error state - check SECOND to ensure it's reachable
  if (assessmentMutation.isError) {
    return (
      <div className="min-h-screen bg-background">
        <Header title="Assessment Result" subtitle="Step 3 of 3" />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <Card>
            <CardContent className="py-8">
              <div className="flex items-center gap-3 text-destructive mb-4">
                <XCircle className="h-6 w-6" data-testid="icon-error" />
                <h3 className="text-lg font-semibold">Assessment Failed</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                There was an error processing your compliance assessment. Please try again or contact support.
              </p>
              <Link href="/compliance">
                <Button variant="outline" data-testid="button-retry-assessment">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Start New Assessment
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Loading state - check SECOND
  if (assessmentMutation.isPending || !decision) {
    return (
      <div className="min-h-screen bg-background">
        <Header title="Assessment Result" subtitle="Step 3 of 3" />
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" data-testid="loader-assessment" />
              <p className="text-lg text-muted-foreground">Assessing compliance with POL 2114...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Safely get outcome config with fallback
  const outcomeConfig = OUTCOME_STYLES[decision.outcome] || OUTCOME_STYLES['REFER'];
  const OutcomeIcon = decision.outcome === 'PERMITTED' ? CheckCircle2 :
    decision.outcome === 'REFER' ? AlertTriangle : XCircle;

  return (
    <div className="min-h-screen bg-background">
      <Header title="Assessment Result" subtitle="Step 3 of 3" />

      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <div className="text-sm text-muted-foreground mb-6 text-right">
            Step 3 of 3: Decision
          </div>
        </div>

        <Card className={`border-l-8 ${outcomeConfig.border} ${outcomeConfig.bg} mb-8`}>
          <CardHeader>
            <div className="flex items-start gap-4">
              <div className={`w-16 h-16 rounded-lg ${outcomeConfig.bg} border-2 ${outcomeConfig.border} flex items-center justify-center flex-shrink-0`}>
                <OutcomeIcon className={`w-8 h-8 ${outcomeConfig.icon}`} />
              </div>
              <div className="flex-1">
                <Badge className={`${outcomeConfig.badge} text-lg px-4 py-1 mb-3`}>
                  {decision.outcome}
                </Badge>
                <CardTitle className="text-2xl mb-2">Decision: {decision.outcome}</CardTitle>
                <CardDescription className={`text-base ${outcomeConfig.text} leading-relaxed`}>
                  {decision.explanation}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        <div className="space-y-6 mb-8">
          {decision.outcome !== 'PROHIBITED' && decision.safeguards?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  Required Safeguards
                </CardTitle>
                <CardDescription>
                  You must implement these safeguards to proceed compliantly:
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {decision.safeguards?.map((safeguard, idx) => (
                    <li key={idx} className="flex items-start gap-2 p-3 rounded-lg bg-muted/50">
                      <span className="text-green-600 mt-1">✓</span>
                      <span className="text-sm text-foreground">{safeguard}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {decision.referrals?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                  Contact for Approval / Assessment
                </CardTitle>
                <CardDescription>
                  Before proceeding, you must contact the following officers for approval and risk assessment:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {decision.referrals?.map((referral, idx) => (
                  <div key={idx} className="p-4 rounded-lg bg-amber-50 border-l-4 border-l-amber-500">
                    <div className="mb-2">
                      <h4 className="font-semibold text-foreground">{referral.contact}</h4>
                      <p className="text-sm text-muted-foreground">{referral.role}</p>
                    </div>
                    <p className="text-sm text-foreground mb-3"><strong>Reason:</strong> {referral.reason}</p>
                    <div className="flex flex-col gap-1 text-sm">
                      {referral.email && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="w-4 h-4" />
                          <span>{referral.email}</span>
                        </div>
                      )}
                      {referral.phone && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Phone className="w-4 h-4" />
                          <span>{referral.phone}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {decision.risks?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-destructive" />
                  Identified Risks
                </CardTitle>
                <CardDescription>
                  The following risks were identified in your planned AI use:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {decision.risks?.map((risk, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-lg border-l-4 ${
                      risk.severity === 'CRITICAL' ? 'bg-red-50 border-l-red-600' :
                      risk.severity === 'HIGH' ? 'bg-orange-50 border-l-orange-500' :
                      risk.severity === 'MEDIUM' ? 'bg-amber-50 border-l-amber-500' :
                      'bg-yellow-50 border-l-yellow-500'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-foreground">{risk.category}</h4>
                      <Badge variant="outline" className="text-xs">
                        {risk.severity}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">{risk.description}</p>
                    <p className="text-xs text-muted-foreground"><strong>Policy Reference:</strong> {risk.clause}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Relevant Policy Clauses</CardTitle>
              <CardDescription>
                Your assessment references the following sections of POL 2114:
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {decision.policyClauses?.map((clause, idx) => (
                  <Badge key={idx} variant="outline" className="text-sm">
                    {clause}
                  </Badge>
                )) || <p className="text-sm text-muted-foreground">No specific policy clauses referenced</p>}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardHeader>
              <CardTitle>Task Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div>
                <span className="font-semibold text-foreground">Department:</span>{' '}
                <span className="text-muted-foreground">{department}</span>
              </div>
              <div>
                <span className="font-semibold text-foreground">AI Tool:</span>{' '}
                <span className="text-muted-foreground">{tool}</span>
              </div>
              <div>
                <span className="font-semibold text-foreground">Purpose:</span>{' '}
                <span className="text-muted-foreground">{purpose}</span>
              </div>
              <div className="pt-2 border-t">
                <span className="font-semibold text-foreground block mb-1">Task Description:</span>
                <span className="text-muted-foreground">{task}</span>
              </div>
              <div className="pt-2 text-xs text-muted-foreground">
                Assessment completed: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col gap-4">
          <Button
            size="lg"
            onClick={handleExport}
            className="w-full gap-2"
            data-testid="button-export-pdf"
          >
            <Download className="w-4 h-4" />
            Export Assessment as PDF
          </Button>

          <div className="flex gap-3">
            <Link href="/compliance" className="flex-1">
              <Button variant="outline" size="lg" className="w-full" data-testid="button-new-assessment">
                Start New Assessment
              </Button>
            </Link>
            <Link href="/" className="flex-1">
              <Button variant="outline" size="lg" className="w-full gap-2" data-testid="button-home">
                <Home className="w-4 h-4" />
                Return to Home
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
