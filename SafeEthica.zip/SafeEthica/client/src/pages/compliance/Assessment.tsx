import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import type { AssessmentResponses } from "@shared/schema";

const ASSESSMENT_QUESTIONS = [
  {
    category: 'Data Protection',
    questions: [
      {
        id: 'containsPersonalData' as keyof AssessmentResponses,
        question: 'Will you input personal data (names, addresses, sensitive information)?',
        help: 'Personal data includes any information that can identify an individual: names, addresses, email addresses, health information, etc.',
      },
      {
        id: 'containsSensitiveInfo' as keyof AssessmentResponses,
        question: 'Will you input operationally sensitive information not suitable for public disclosure?',
        help: 'This includes incident details with names/locations, internal communications, confidential business information, etc.',
      },
    ],
  },
  {
    category: 'Risk & Security',
    questions: [
      {
        id: 'exposesConfidential' as keyof AssessmentResponses,
        question: 'Could this task expose confidential, commercially sensitive, or security-critical information?',
        help: 'Consider whether the AI tool could access or learn from data that should remain private.',
      },
      {
        id: 'toolMeetsSecurity' as keyof AssessmentResponses,
        question: 'Are you confident the AI tool meets NFRS cyber security standards?',
        help: 'Approved tools include Microsoft Copilot M365. If unsure, select "No" or "Unsure".',
      },
    ],
  },
  {
    category: 'Copyright & Accuracy',
    questions: [
      {
        id: 'copyrightRisk' as keyof AssessmentResponses,
        question: 'Could the AI-generated content infringe copyright or intellectual property rights?',
        help: 'AI may reproduce copyrighted material from its training data.',
      },
      {
        id: 'willVerifyOutputs' as keyof AssessmentResponses,
        question: 'Will you personally review and verify all AI outputs before use?',
        help: 'Human review is mandatory. You remain accountable for all AI-assisted content.',
      },
      {
        id: 'understandsAccountability' as keyof AssessmentResponses,
        question: 'Do you understand you are accountable for any AI-generated content used?',
        help: 'You cannot blame the AI for errors or inappropriate content - you are responsible.',
      },
    ],
  },
  {
    category: 'Confidentiality & Ethics',
    questions: [
      {
        id: 'reidentificationRisk' as keyof AssessmentResponses,
        question: 'Could pseudonymized data be re-identified through AI processing?',
        help: 'Even if names are removed, AI might combine data points to identify individuals.',
      },
      {
        id: 'couldCauseBias' as keyof AssessmentResponses,
        question: 'Could the AI output be discriminatory, offensive, or harmful to vulnerable communities?',
        help: 'AI can perpetuate biases. Consider equality impact, especially for public-facing content.',
      },
      {
        id: 'alignsWithEthics' as keyof AssessmentResponses,
        question: 'Does this align with NFRS Core Code of Ethics (Integrity, Respect, Professionalism, Accountability, Inclusivity)?',
        help: 'All AI use must support, not undermine, our core values.',
      },
    ],
  },
  {
    category: 'Legal & Disclosure',
    questions: [
      {
        id: 'compliesLegal' as keyof AssessmentResponses,
        question: 'Does this comply with UK GDPR, Data Protection Act 2018, and relevant regulations?',
        help: 'If unsure, select "Unsure" and the assessment will guide you to appropriate contacts.',
      },
      {
        id: 'willDisclose' as keyof AssessmentResponses,
        question: 'Will you clearly identify any AI-generated content as such?',
        help: 'Transparency is required - readers must know content was produced with AI assistance.',
      },
    ],
  },
];

export default function Assessment() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);

  const [responses, setResponses] = useState<AssessmentResponses>({
    containsPersonalData: '' as 'yes',
    containsSensitiveInfo: '' as 'yes',
    exposesConfidential: '' as 'yes',
    toolMeetsSecurity: '' as 'yes',
    copyrightRisk: '' as 'yes',
    willVerifyOutputs: '' as 'yes',
    understandsAccountability: '' as 'yes',
    reidentificationRisk: '' as 'yes',
    couldCauseBias: '' as 'yes',
    alignsWithEthics: '' as 'yes',
    compliesLegal: '' as 'yes',
    willDisclose: '' as 'yes',
  });

  const updateResponse = (id: keyof AssessmentResponses, value: 'yes' | 'no' | 'unsure') => {
    setResponses({ ...responses, [id]: value });
  };

  const allAnswered = Object.values(responses).every(r => r !== '');

  const handleSubmit = () => {
    params.set('responses', JSON.stringify(responses));
    setLocation(`/compliance/result?${params.toString()}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="Policy Assessment Questions" subtitle="Step 2 of 3" />

      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <Button
              variant="ghost"
              className="gap-2"
              onClick={() => setLocation(`/compliance/task?${params.toString()}`)}
              data-testid="button-back"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <div className="text-sm text-muted-foreground">
              Step 2 of 3: Assessment
            </div>
          </div>

          <h1 className="text-3xl font-bold text-foreground mb-3">POL 2114 Compliance Assessment</h1>
          <p className="text-lg text-muted-foreground">
            Answer the following questions honestly to determine if your planned AI use complies with 
            NFRS policy. Select "Unsure" if you're not certain.
          </p>
        </div>

        <div className="space-y-8 mb-8">
          {ASSESSMENT_QUESTIONS.map((section, sectionIdx) => (
            <div key={section.category} className="space-y-4">
              <div className="bg-primary/5 border-l-4 border-l-primary rounded-r-lg p-4">
                <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                  <span className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                    {sectionIdx + 1}
                  </span>
                  {section.category}
                </h2>
              </div>
              
              <div className="space-y-5 pl-4">
                {section.questions.map((q, qIdx) => (
                  <Card key={q.id} className="border-2 hover-elevate transition-all">
                    <CardContent className="p-5 space-y-4">
                      <div className="flex gap-3">
                        <div className="bg-muted text-muted-foreground w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-1">
                          {qIdx + 1}
                        </div>
                        <div className="flex-1">
                          <Label className="text-base font-semibold text-foreground leading-relaxed">{q.question}</Label>
                          {q.help && (
                            <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{q.help}</p>
                          )}
                        </div>
                      </div>
                      
                      <RadioGroup
                        value={responses[q.id]}
                        onValueChange={(value: 'yes' | 'no' | 'unsure') => updateResponse(q.id, value)}
                        className="pl-9"
                      >
                        <div className="flex gap-3">
                          <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate flex-1">
                            <RadioGroupItem value="yes" id={`${q.id}-yes`} data-testid={`radio-${q.id}-yes`} />
                            <Label htmlFor={`${q.id}-yes`} className="flex-1 cursor-pointer font-medium">
                              Yes
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate flex-1">
                            <RadioGroupItem value="no" id={`${q.id}-no`} data-testid={`radio-${q.id}-no`} />
                            <Label htmlFor={`${q.id}-no`} className="flex-1 cursor-pointer font-medium">
                              No
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate flex-1">
                            <RadioGroupItem value="unsure" id={`${q.id}-unsure`} data-testid={`radio-${q.id}-unsure`} />
                            <Label htmlFor={`${q.id}-unsure`} className="flex-1 cursor-pointer font-medium">
                              Unsure
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation(`/compliance/task?${params.toString()}`)}
            data-testid="button-back-task"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Task
          </Button>
          <Button
            size="lg"
            onClick={handleSubmit}
            disabled={!allAnswered}
            className="gap-2"
            data-testid="button-get-decision"
          >
            Get Decision
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </main>
    </div>
  );
}
