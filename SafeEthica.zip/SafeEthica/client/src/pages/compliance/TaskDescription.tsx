import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { AI_TOOLS, AI_PURPOSES } from "@/data/constants";

export default function TaskDescription() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const department = params.get('dept') || '';

  const [taskDescription, setTaskDescription] = useState('');
  const [aiTool, setAiTool] = useState('');
  const [otherTool, setOtherTool] = useState('');
  const [purpose, setPurpose] = useState('');
  const [otherPurpose, setOtherPurpose] = useState('');

  const handleNext = () => {
    const queryParams = new URLSearchParams({
      dept: department,
      task: taskDescription,
      tool: aiTool === 'other' ? otherTool : aiTool,
      purpose: purpose === 'other' ? otherPurpose : purpose,
    });
    setLocation(`/compliance/assessment?${queryParams.toString()}`);
  };

  const canProceed = taskDescription && aiTool && purpose &&
    (aiTool !== 'other' || otherTool) &&
    (purpose !== 'other' || otherPurpose);

  return (
    <div className="min-h-screen bg-background">
      <Header title="Task Description" subtitle="Step 1 of 3" />

      <main className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <Button
              variant="ghost"
              className="gap-2"
              onClick={() => setLocation('/compliance')}
              data-testid="button-back"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <div className="text-sm text-muted-foreground">
              Step 1 of 3: Task Description
            </div>
          </div>

          <h1 className="text-3xl font-bold text-foreground mb-3">Describe What You Want to Accomplish</h1>
          <p className="text-lg text-muted-foreground">
            Provide details about the task you're planning to use AI for. Be as specific as possible 
            to receive accurate guidance.
          </p>
        </div>

        <div className="space-y-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Task Description</CardTitle>
              <CardDescription>
                What do you want to accomplish with AI? Describe the specific task, the information 
                you'll be working with, and what output you need.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example: I want to use AI to summarize a 20-page incident report into a 1-page executive summary for the Fire Authority. The report contains incident details, crew actions, and outcomes..."
                className="min-h-32 resize-none"
                value={taskDescription}
                onChange={(e) => setTaskDescription(e.target.value)}
                data-testid="input-task-description"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Be specific about what data you'll input and what you need the AI to produce.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI Tool</CardTitle>
              <CardDescription>
                Which AI tool do you plan to use for this task?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup value={aiTool} onValueChange={setAiTool}>
                {AI_TOOLS.map((tool) => (
                  <div key={tool.value} className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                    <RadioGroupItem value={tool.value} id={tool.value} data-testid={`radio-tool-${tool.value}`} />
                    <Label htmlFor={tool.value} className="flex-1 cursor-pointer">
                      {tool.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              {aiTool === 'other' && (
                <div className="mt-4">
                  <Label htmlFor="other-tool" className="mb-2 block">
                    Specify the AI tool
                  </Label>
                  <Input
                    id="other-tool"
                    placeholder="e.g., Claude, Gemini, specific industry tool..."
                    value={otherTool}
                    onChange={(e) => setOtherTool(e.target.value)}
                    data-testid="input-other-tool"
                  />
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Primary Purpose</CardTitle>
              <CardDescription>
                What is the main purpose of using AI for this task?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup value={purpose} onValueChange={setPurpose}>
                {AI_PURPOSES.map((p) => (
                  <div key={p.value} className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                    <RadioGroupItem value={p.value} id={p.value} data-testid={`radio-purpose-${p.value}`} />
                    <Label htmlFor={p.value} className="flex-1 cursor-pointer">
                      {p.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              {purpose === 'other' && (
                <div className="mt-4">
                  <Label htmlFor="other-purpose" className="mb-2 block">
                    Specify the purpose
                  </Label>
                  <Input
                    id="other-purpose"
                    placeholder="e.g., Image generation, code assistance..."
                    value={otherPurpose}
                    onChange={(e) => setOtherPurpose(e.target.value)}
                    data-testid="input-other-purpose"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation('/compliance')}
            data-testid="button-back-start"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Start
          </Button>
          <Button
            size="lg"
            onClick={handleNext}
            disabled={!canProceed}
            className="gap-2"
            data-testid="button-continue"
          >
            Continue to Assessment
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </main>
    </div>
  );
}
