import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, ClipboardCheck, Info, Shield } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { DEPARTMENTS } from "@/data/constants";

export default function ComplianceHome() {
  const [, setLocation] = useLocation();
  const [department, setDepartment] = useState('');

  const handleStart = () => {
    if (department) {
      setLocation(`/compliance/task?dept=${department}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-4 border-compliance bg-compliance/5 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ClipboardCheck className="w-8 h-8 text-compliance" />
              <div>
                <h1 className="text-xl font-bold text-compliance">AI Policy Compliance Checker</h1>
                <p className="text-sm text-muted-foreground">Quick Assessment Tool</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="gap-2 mb-6" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Button>
          </Link>

          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 rounded-lg bg-compliance/10 flex items-center justify-center flex-shrink-0">
              <Shield className="w-8 h-8 text-compliance" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-3">
                Check if Your AI Use Complies with POL 2114
              </h1>
              <p className="text-lg text-muted-foreground">
                Before using AI tools for any task, complete this quick 5-minute assessment to understand 
                whether your planned use is permitted, requires approval, or is prohibited.
              </p>
            </div>
          </div>
        </div>

        <Card className="mb-8 border-l-4 border-l-compliance">
          <CardHeader>
            <CardTitle>How This Assessment Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-2">
              <span className="text-compliance font-bold mt-0.5">1.</span>
              <p className="text-sm text-foreground">
                <strong>Describe your task:</strong> Tell us what you want to accomplish with AI and which tool you plan to use
              </p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-compliance font-bold mt-0.5">2.</span>
              <p className="text-sm text-foreground">
                <strong>Answer guided questions:</strong> Respond to questions about data protection, security, accuracy, and ethics
              </p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-compliance font-bold mt-0.5">3.</span>
              <p className="text-sm text-foreground">
                <strong>Get clear guidance:</strong> Receive a decision (Permitted/Refer/Prohibited) with specific next steps and policy references
              </p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-compliance font-bold mt-0.5">4.</span>
              <p className="text-sm text-foreground">
                <strong>Export for records:</strong> Save your assessment as a PDF for compliance documentation
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <Label htmlFor="department" className="text-lg font-semibold text-foreground mb-2">
              Select Your Department
            </Label>
            <CardDescription>
              This helps us provide department-specific guidance and route referrals appropriately.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={department} onValueChange={setDepartment}>
              <SelectTrigger id="department" className="w-full" data-testid="select-department">
                <SelectValue placeholder="Choose your department..." />
              </SelectTrigger>
              <SelectContent>
                {DEPARTMENTS.map((dept) => (
                  <SelectItem key={dept.value} value={dept.value}>
                    {dept.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="bg-compliance/5 border-l-4 border-l-compliance mb-8">
          <CardHeader>
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-compliance mt-0.5" />
              <div>
                <CardTitle className="text-lg">Privacy Notice</CardTitle>
                <CardDescription className="mt-2 text-sm leading-relaxed">
                  This assessment does not collect personal data. Only your department and anonymized 
                  assessment data (for reporting purposes) are recorded. Your specific task description 
                  and decisions remain private unless you choose to share the exported PDF.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        <div className="flex justify-between items-center">
          <Link href="/">
            <Button variant="outline" size="lg" data-testid="button-cancel">
              Cancel
            </Button>
          </Link>
          <Button
            size="lg"
            onClick={handleStart}
            disabled={!department}
            className="gap-2 bg-compliance hover:bg-compliance/90 text-compliance-foreground"
            data-testid="button-start-assessment"
          >
            Start Assessment
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </main>
    </div>
  );
}
