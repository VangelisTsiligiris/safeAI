import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, Calendar, HardDrive, BookOpen, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

interface Resource {
  id: string;
  name: string;
  size: number;
  uploadedAt: string;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
}

export default function Resources() {
  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ['/api/resources'],
  });

  const handleDownload = (resourceId: string) => {
    window.location.href = `/api/resources/${resourceId}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-4 border-nfrs-red bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 bg-nfrs-red rounded flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-nfrs-dark-grey">Resources</h1>
                <p className="text-sm text-muted-foreground">Training Materials & Policy Documents</p>
              </div>
            </div>
            <Link href="/">
              <Button variant="outline" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-8">
          <Alert className="border-resources-color bg-resources-color/5">
            <AlertCircle className="h-4 w-4 text-resources-color" />
            <AlertTitle className="text-resources-color font-semibold">Resource Library</AlertTitle>
            <AlertDescription className="text-muted-foreground">
              Access training materials, policy documents, and guidance resources for responsible AI use at NFRS.
              All resources are approved and maintained by authorized administrators.
            </AlertDescription>
          </Alert>
        </div>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-10 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : resources.length === 0 ? (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-muted-foreground" />
                No Resources Available
              </CardTitle>
              <CardDescription>
                There are currently no resources uploaded. Check back later or contact your administrator.
              </CardDescription>
            </CardHeader>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {resources.map((resource) => (
              <Card 
                key={resource.id} 
                className="hover-elevate transition-all"
                data-testid={`card-resource-${resource.id}`}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <FileText className="h-4 w-4 text-resources-color flex-shrink-0" />
                    <span className="truncate" title={resource.name}>
                      {resource.name}
                    </span>
                  </CardTitle>
                  <CardDescription className="space-y-1">
                    <div className="flex items-center gap-2 text-xs">
                      <HardDrive className="h-3 w-3" />
                      {formatFileSize(resource.size)}
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <Calendar className="h-3 w-3" />
                      {formatDate(resource.uploadedAt)}
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    onClick={() => handleDownload(resource.id)}
                    className="w-full"
                    variant="default"
                    data-testid={`button-download-${resource.id}`}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
