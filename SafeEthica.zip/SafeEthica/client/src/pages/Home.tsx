import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, ClipboardCheck, Shield, Info, LogOut, Settings, BookOpen } from "lucide-react";
import { useAdmin } from "@/hooks/useAdmin";

export default function Home() {
  const { isAdmin } = useAdmin();
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-4 border-nfrs-red bg-white">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-10 h-10 text-nfrs-red" />
              <div>
                <h1 className="text-2xl font-bold text-nfrs-dark-grey">NFRS AI Toolkit</h1>
                <p className="text-sm text-muted-foreground">Safe, Ethical & Responsible AI</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {isAdmin && (
                <Link href="/admin">
                  <Button variant="outline" data-testid="button-admin">
                    <Settings className="w-4 h-4 mr-2" />
                    Admin
                  </Button>
                </Link>
              )}
              <Button 
                variant="outline" 
                onClick={() => window.location.href = "/api/logout"}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Log Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Welcome to the Nottinghamshire Fire & Rescue Service AI Toolkit
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Supporting responsible and compliant use of artificial intelligence across NFRS, 
            aligned with POL 2114 and our Core Code of Ethics.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <Card className="border-2 border-l-4 border-l-workshop hover-elevate transition-all" data-testid="card-workshop">
            <CardHeader className="space-y-3">
              <div className="w-16 h-16 rounded-lg bg-workshop/10 flex items-center justify-center">
                <GraduationCap className="w-8 h-8 text-workshop" />
              </div>
              <CardTitle className="text-2xl">Workshop Learning Platform</CardTitle>
              <CardDescription className="text-base">
                Interactive training for all NFRS employees on AI governance, risks, and policy compliance.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-workshop mt-0.5">•</span>
                  <span>Educational content on AI fundamentals for fire services</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-workshop mt-0.5">•</span>
                  <span>Risk & ethics framework with NFRS-specific examples</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-workshop mt-0.5">•</span>
                  <span>Interactive scenario exercises with facilitation tools</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-workshop mt-0.5">•</span>
                  <span>Departmental action plan builder and PDF export</span>
                </li>
              </ul>
              <Link href="/workshop">
                <Button className="w-full bg-workshop hover:bg-workshop/90 text-workshop-foreground" size="lg" data-testid="button-start-workshop">
                  Start Workshop
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-2 border-l-4 border-l-compliance hover-elevate transition-all" data-testid="card-compliance">
            <CardHeader className="space-y-3">
              <div className="w-16 h-16 rounded-lg bg-compliance/10 flex items-center justify-center">
                <ClipboardCheck className="w-8 h-8 text-compliance" />
              </div>
              <CardTitle className="text-2xl">AI Policy Compliance Checker</CardTitle>
              <CardDescription className="text-base">
                Quick assessment tool to check if your planned AI use aligns with POL 2114.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-compliance mt-0.5">•</span>
                  <span>5-minute guided assessment questionnaire</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-compliance mt-0.5">•</span>
                  <span>Clear decision: Permitted, Refer, or Prohibited</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-compliance mt-0.5">•</span>
                  <span>Specific safeguards and policy references</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-compliance mt-0.5">•</span>
                  <span>Contact information for referrals and PDF export</span>
                </li>
              </ul>
              <Link href="/compliance">
                <Button className="w-full bg-compliance hover:bg-compliance/90 text-compliance-foreground" size="lg" data-testid="button-start-compliance">
                  Check Compliance
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-2 border-l-4 border-l-resources-color hover-elevate transition-all" data-testid="card-resources">
            <CardHeader className="space-y-3">
              <div className="w-16 h-16 rounded-lg bg-resources-color/10 flex items-center justify-center">
                <BookOpen className="w-8 h-8 text-resources-color" />
              </div>
              <CardTitle className="text-2xl">Resource Library</CardTitle>
              <CardDescription className="text-base">
                Access training materials, policy documents, and approved guidance resources.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-resources-color mt-0.5">•</span>
                  <span>NFRS AI policy documentation and guidelines</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-resources-color mt-0.5">•</span>
                  <span>Training materials and workshop resources</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-resources-color mt-0.5">•</span>
                  <span>Best practice guides and case studies</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-resources-color mt-0.5">•</span>
                  <span>Downloadable templates and reference materials</span>
                </li>
              </ul>
              <Link href="/resources">
                <Button className="w-full bg-resources-color hover:bg-resources-color/90 text-resources-foreground" size="lg" data-testid="button-view-resources">
                  View Resources
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-muted/30 border-l-4 border-l-primary">
          <CardHeader>
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <CardTitle className="text-lg">About This Toolkit</CardTitle>
                <CardDescription className="mt-2 text-base leading-relaxed">
                  This toolkit supports Nottinghamshire Fire & Rescue Service's commitment to safe, 
                  ethical, and responsible use of artificial intelligence. All content and guidance 
                  aligns with POL 2114 (Artificial Intelligence Policy), NFRS Core Code of Ethics, 
                  and the Annual Delivery Plan 2025-26.
                </CardDescription>
                <CardDescription className="mt-3 text-sm">
                  <strong>Key Contacts:</strong> Information Governance Officer (Data Protection), 
                  ICT Security Manager (Cyber Security), Organisational Development and Inclusion Manager (Ethics)
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>
      </main>

      <footer className="border-t mt-16 py-6">
        <div className="max-w-7xl mx-auto px-6 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Nottinghamshire Fire & Rescue Service. All rights reserved.</p>
          <p className="mt-1">POL 2114 - Artificial Intelligence Policy | Version 1.0</p>
        </div>
      </footer>
    </div>
  );
}
