import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ArrowRight, Download, Building2 } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { DEPARTMENTS, GOVERNANCE_TOUCHPOINTS } from "@/data/constants";
import { generateActionPlanPDF } from "@/utils/pdfGenerator";

export default function ActionPlan() {
  const [department, setDepartment] = useState('');
  const [aiUseCases, setAiUseCases] = useState('');
  const [riskMitigation, setRiskMitigation] = useState('');
  const [trainingNeeds, setTrainingNeeds] = useState('');
  const [selectedTouchpoints, setSelectedTouchpoints] = useState<string[]>([]);
  const [targetDates, setTargetDates] = useState('');

  const toggleTouchpoint = (touchpoint: string) => {
    if (selectedTouchpoints.includes(touchpoint)) {
      setSelectedTouchpoints(selectedTouchpoints.filter(t => t !== touchpoint));
    } else {
      setSelectedTouchpoints([...selectedTouchpoints, touchpoint]);
    }
  };

  const handleExport = () => {
    if (!department || !aiUseCases || !riskMitigation || !trainingNeeds) {
      alert('Please complete all required fields before exporting.');
      return;
    }
    
    const actionPlan = {
      department,
      aiUseCases,
      riskMitigation,
      trainingNeeds,
      governanceTouchpoints: selectedTouchpoints,
      targetDates,
    };
    
    generateActionPlanPDF(actionPlan);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="Departmental Action Plan" subtitle="Module 4 of 4" />

      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/workshop">
            <Button variant="ghost" className="gap-2" data-testid="button-back-workshop">
              <ArrowLeft className="w-4 h-4" />
              Back to Workshop
            </Button>
          </Link>
          <Badge variant="outline" className="text-sm">15 minutes</Badge>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-3">Build Your Department's AI Action Plan</h1>
          <p className="text-lg text-muted-foreground">
            Identify how your department will use AI responsibly, what safeguards you'll put in place, 
            and what support you need from NFRS governance functions.
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-start gap-3">
              <Building2 className="w-6 h-6 text-primary mt-1" />
              <div>
                <CardTitle>Department Selection</CardTitle>
                <CardDescription className="mt-1">
                  Select your department to customize the action plan template
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Select value={department} onValueChange={setDepartment}>
              <SelectTrigger className="w-full" data-testid="select-department">
                <SelectValue placeholder="Select your department..." />
              </SelectTrigger>
              <SelectContent>
                {DEPARTMENTS.map((dept) => (
                  <SelectItem key={dept.value} value={dept.value}>
                    {dept.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <div className="space-y-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Current or Planned AI Use Cases</CardTitle>
              <CardDescription>
                What AI tools or applications are you currently using or planning to use in your department? 
                Consider analytical AI, generative AI, and automation tools.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example: Using Microsoft Copilot for summarizing incident reports, considering AI analysis of fire risk data to target prevention resources..."
                className="min-h-32 resize-none"
                value={aiUseCases}
                onChange={(e) => setAiUseCases(e.target.value)}
                data-testid="input-use-cases"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risk Mitigation Measures</CardTitle>
              <CardDescription>
                What specific actions will you take to ensure AI use in your department complies with POL 2114? 
                Consider data protection, accuracy checks, bias prevention, and human oversight.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example: All AI-generated content will be reviewed by a senior officer before publication. Personal data will never be entered into external AI tools. We will establish a checklist for staff to follow..."
                className="min-h-32 resize-none"
                value={riskMitigation}
                onChange={(e) => setRiskMitigation(e.target.value)}
                data-testid="input-risk-mitigation"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Training and Guidance Needs</CardTitle>
              <CardDescription>
                What training, guidance, or resources does your team need to use AI safely and effectively? 
                What skills gaps need to be addressed?
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example: Team briefing on POL 2114 requirements, hands-on training with Microsoft Copilot, guidance on what data can and cannot be shared with AI tools..."
                className="min-h-32 resize-none"
                value={trainingNeeds}
                onChange={(e) => setTrainingNeeds(e.target.value)}
                data-testid="input-training-needs"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Governance Touchpoints</CardTitle>
              <CardDescription>
                Who do you need to engage with to ensure proper oversight and approval for your AI use cases? 
                Select all that apply.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-3">
                {GOVERNANCE_TOUCHPOINTS.map((touchpoint) => (
                  <div key={touchpoint} className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                    <Checkbox
                      id={touchpoint}
                      checked={selectedTouchpoints.includes(touchpoint)}
                      onCheckedChange={() => toggleTouchpoint(touchpoint)}
                      data-testid={`checkbox-${touchpoint.toLowerCase().replace(/\s+/g, '-')}`}
                    />
                    <Label htmlFor={touchpoint} className="flex-1 cursor-pointer text-sm">
                      {touchpoint}
                    </Label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Target Dates and Milestones</CardTitle>
              <CardDescription>
                When will you complete these actions? Set realistic timelines for implementation, training, and review.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example: Complete team briefing by [Date], implement AI usage checklist by [Date], conduct first quarterly review by [Date]..."
                className="min-h-24 resize-none"
                value={targetDates}
                onChange={(e) => setTargetDates(e.target.value)}
                data-testid="input-target-dates"
              />
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between gap-4">
          <Link href="/workshop/scenarios">
            <Button variant="outline" size="lg" className="gap-2" data-testid="button-prev-module">
              <ArrowLeft className="w-4 h-4" />
              Back to Scenarios
            </Button>
          </Link>
          <div className="flex gap-3">
            <Button
              variant="outline"
              size="lg"
              onClick={handleExport}
              className="gap-2"
              data-testid="button-export-pdf"
            >
              <Download className="w-4 h-4" />
              Export as PDF
            </Button>
            <Link href="/workshop/summary">
              <Button size="lg" className="gap-2" data-testid="button-view-summary">
                View Workshop Summary
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
