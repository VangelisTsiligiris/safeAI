import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, AlertTriangle, ShieldAlert, Lock, Users, Brain, Scale, Download } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { RISK_ETHICS_FRAMEWORK } from "@/data/frameworkContent";
import { Badge } from "@/components/ui/badge";
import { exportRisksAndEthics } from "@/lib/pdfExport";

const icons = {
  0: AlertTriangle,
  1: ShieldAlert,
  2: Lock,
  3: Users,
  4: Brain,
  5: Scale,
};

export default function RisksEthics() {
  const handleExportPDF = () => {
    const content = RISK_ETHICS_FRAMEWORK.subsections.map(subsection => ({
      title: subsection.heading,
      text: subsection.content,
      examples: subsection.examples,
    }));
    
    const keyTakeaways = [
      'AI risks include hallucination, bias, data breaches, and loss of human accountability',
      'POL 2114 provides policy controls and safeguards to manage each risk category',
      'NFRS Core Code of Ethics demands fairness, transparency, and respect in all AI use',
      'Prohibited AI uses include facial recognition and fully automated decision-making',
      'Personal data must never be entered into unapproved AI systems',
    ];
    
    exportRisksAndEthics(content, keyTakeaways);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="Risk & Ethics Framework" subtitle="Module 2 of 4" />

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/workshop">
            <Button variant="ghost" className="gap-2" data-testid="button-back-workshop">
              <ArrowLeft className="w-4 h-4" />
              Back to Workshop
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportPDF}
              className="gap-2"
              data-testid="button-export-pdf"
            >
              <Download className="w-4 h-4" />
              Export PDF
            </Button>
            <Badge variant="outline" className="text-sm">15 minutes</Badge>
          </div>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-3">{RISK_ETHICS_FRAMEWORK.title}</h1>
          <p className="text-lg text-muted-foreground">
            Understanding the key risks of AI use in fire services and how POL 2114 helps manage them 
            through policy controls and safeguards.
          </p>
        </div>

        <div className="space-y-6 mb-12">
          {RISK_ETHICS_FRAMEWORK.subsections.map((subsection, index) => {
            const Icon = icons[index as keyof typeof icons] || AlertTriangle;
            return (
              <Card key={subsection.heading} className="border-l-4 border-l-destructive/60" data-testid={`card-risk-${index}`}>
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-destructive" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{subsection.heading}</CardTitle>
                      <CardDescription className="text-base text-foreground leading-relaxed">
                        {subsection.content}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                {subsection.examples && subsection.examples.length > 0 && (
                  <CardContent>
                    <div className="space-y-3">
                      {subsection.examples.map((example, idx) => {
                        const isPolicy = example.includes('Policy Control');
                        return (
                          <div
                            key={idx}
                            className={`rounded-lg p-4 ${
                              isPolicy ? 'bg-primary/10 border-l-4 border-l-primary' : 'bg-muted/50'
                            }`}
                          >
                            <p className="text-sm text-foreground font-medium">{example}</p>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        <Card className="bg-destructive/5 border-2 border-destructive/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              Critical Reminders
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-2">
              <span className="text-destructive mt-1 font-bold">!</span>
              <p className="text-sm text-foreground"><strong>All AI outputs must be reviewed by a competent human</strong> before use - you remain accountable</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-destructive mt-1 font-bold">!</span>
              <p className="text-sm text-foreground"><strong>Never enter personal data</strong> into unapproved AI systems (Section 8 Prohibited Use)</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-destructive mt-1 font-bold">!</span>
              <p className="text-sm text-foreground"><strong>Consider bias and discrimination</strong> in all AI applications, especially those affecting vulnerable communities</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-destructive mt-1 font-bold">!</span>
              <p className="text-sm text-foreground"><strong>Maintain human judgment</strong> - AI is a tool to support, not replace, professional expertise</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-between mt-8">
          <Link href="/workshop/fundamentals">
            <Button variant="outline" size="lg" className="gap-2" data-testid="button-prev-module">
              <ArrowLeft className="w-4 h-4" />
              Previous Module
            </Button>
          </Link>
          <Link href="/workshop/scenarios">
            <Button size="lg" className="gap-2" data-testid="button-next-module">
              Next Module: Scenarios
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
