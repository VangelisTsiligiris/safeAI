import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ArrowRight, ChevronDown, ChevronUp, Info, CheckCircle2, Download } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { Timer } from "@/components/shared/Timer";
import { SCENARIOS } from "@/data/scenarios";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useAdmin } from "@/hooks/useAdmin";
import { useQuery } from "@tanstack/react-query";
import { exportScenarios } from "@/lib/pdfExport";

interface ScenarioResponse {
  risks: string;
  policyClauses: string;
  safeguards: string;
  recommendation: 'permit' | 'refer' | 'prohibit' | '';
  notes: string;
  completed: boolean;
}

export default function WorkshopScenarios() {
  const { isAdmin } = useAdmin();
  const [currentScenario, setCurrentScenario] = useState(0);
  const [responses, setResponses] = useState<Record<string, ScenarioResponse>>(
    SCENARIOS.reduce((acc, scenario) => ({
      ...acc,
      [scenario.id]: {
        risks: '',
        policyClauses: '',
        safeguards: '',
        recommendation: '',
        notes: '',
        completed: false,
      }
    }), {})
  );
  const [showFacilitatorNotes, setShowFacilitatorNotes] = useState(false);

  // Fetch facilitator notes for admin users only
  const { data: facilitatorNotes } = useQuery<Record<string, string[]>>({
    queryKey: ['/api/workshop/scenarios/facilitator-notes'],
    enabled: isAdmin, // Only fetch if user is admin
  });

  const scenario = SCENARIOS[currentScenario];
  const response = responses[scenario.id];
  const scenarioFacilitatorNotes = facilitatorNotes?.[scenario.id] || [];

  const updateResponse = (field: keyof ScenarioResponse, value: string) => {
    setResponses({
      ...responses,
      [scenario.id]: {
        ...response,
        [field]: value,
      }
    });
  };

  const markComplete = () => {
    setResponses({
      ...responses,
      [scenario.id]: {
        ...response,
        completed: true,
      }
    });
  };

  const handleExportPDF = () => {
    const scenariosData = SCENARIOS.map(scenario => ({
      title: scenario.title,
      context: scenario.context,
      responses: responses[scenario.id],
    }));
    exportScenarios(scenariosData);
  };

  const completedCount = Object.values(responses).filter(r => r.completed).length;

  return (
    <div className="min-h-screen bg-background">
      <Header title="Interactive Scenario Exercises" subtitle="Module 3 of 4" />

      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/workshop">
            <Button variant="ghost" className="gap-2" data-testid="button-back-workshop">
              <ArrowLeft className="w-4 h-4" />
              Back to Workshop
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportPDF}
              className="gap-2"
              data-testid="button-export-pdf"
            >
              <Download className="w-4 h-4" />
              Export PDF
            </Button>
            <Badge variant={completedCount === SCENARIOS.length ? "default" : "outline"} className="text-sm">
              {completedCount} of {SCENARIOS.length} Completed
            </Badge>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-2 border-primary">
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <Badge className="bg-primary text-primary-foreground">
                    Scenario {currentScenario + 1} of {SCENARIOS.length}
                  </Badge>
                  {response.completed && (
                    <Badge variant="outline" className="gap-1 border-green-500 text-green-700">
                      <CheckCircle2 className="w-3 h-3" />
                      Complete
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-2xl">{scenario.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold text-foreground mb-2">Context</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                    {scenario.context}
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Stakeholders Affected</h3>
                  <div className="flex flex-wrap gap-2">
                    {scenario.stakeholders.map((stakeholder, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {stakeholder}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="bg-primary/5 rounded-lg p-4 border-l-4 border-l-primary">
                  <h3 className="font-semibold text-foreground mb-2">AI Involvement</h3>
                  <p className="text-sm text-foreground">{scenario.aiInvolvement}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Discussion Prompts & Group Response</CardTitle>
                <CardDescription>
                  Use these prompts to guide your group discussion. Capture key points below.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="risks" className="text-base font-semibold text-foreground mb-2 block">
                    {scenario.prompts.risks}
                  </Label>
                  <Textarea
                    id="risks"
                    placeholder="Group discussion notes..."
                    className="min-h-24 resize-none"
                    value={response.risks}
                    onChange={(e) => updateResponse('risks', e.target.value)}
                    data-testid="input-risks"
                  />
                </div>

                <div>
                  <Label htmlFor="policy" className="text-base font-semibold text-foreground mb-2 block">
                    {scenario.prompts.policyClauses}
                  </Label>
                  <Textarea
                    id="policy"
                    placeholder="Relevant POL 2114 sections..."
                    className="min-h-24 resize-none"
                    value={response.policyClauses}
                    onChange={(e) => updateResponse('policyClauses', e.target.value)}
                    data-testid="input-policy"
                  />
                </div>

                <div>
                  <Label htmlFor="safeguards" className="text-base font-semibold text-foreground mb-2 block">
                    {scenario.prompts.safeguards}
                  </Label>
                  <Textarea
                    id="safeguards"
                    placeholder="Proposed safeguards..."
                    className="min-h-24 resize-none"
                    value={response.safeguards}
                    onChange={(e) => updateResponse('safeguards', e.target.value)}
                    data-testid="input-safeguards"
                  />
                </div>

                <div>
                  <Label className="text-base font-semibold text-foreground mb-3 block">
                    {scenario.prompts.recommendation}
                  </Label>
                  <RadioGroup
                    value={response.recommendation}
                    onValueChange={(value) => updateResponse('recommendation', value)}
                  >
                    <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                      <RadioGroupItem value="permit" id="permit" data-testid="radio-permit" />
                      <Label htmlFor="permit" className="flex-1 cursor-pointer">
                        <span className="font-semibold text-green-700">PERMIT</span> (with safeguards)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                      <RadioGroupItem value="refer" id="refer" data-testid="radio-refer" />
                      <Label htmlFor="refer" className="flex-1 cursor-pointer">
                        <span className="font-semibold text-amber-700">REFER</span> for assessment
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 rounded-lg border hover-elevate">
                      <RadioGroupItem value="prohibit" id="prohibit" data-testid="radio-prohibit" />
                      <Label htmlFor="prohibit" className="flex-1 cursor-pointer">
                        <span className="font-semibold text-red-700">PROHIBIT</span> this use
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="notes" className="text-base font-semibold text-foreground mb-2 block">
                    Additional Notes & Key Decisions
                  </Label>
                  <Textarea
                    id="notes"
                    placeholder="Capture any additional discussion points, action items, or decisions..."
                    className="min-h-32 resize-none"
                    value={response.notes}
                    onChange={(e) => updateResponse('notes', e.target.value)}
                    data-testid="input-notes"
                  />
                </div>

                <Button
                  onClick={markComplete}
                  variant={response.completed ? "outline" : "default"}
                  className="w-full"
                  data-testid="button-mark-complete"
                >
                  {response.completed ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Scenario Completed
                    </>
                  ) : (
                    'Mark Scenario as Complete'
                  )}
                </Button>
              </CardContent>
            </Card>

            {isAdmin && scenarioFacilitatorNotes.length > 0 && (
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="facilitator" className="border rounded-lg px-4">
                  <AccordionTrigger className="hover:no-underline" data-testid="button-toggle-facilitator">
                    <div className="flex items-center gap-2">
                      <Info className="w-5 h-5 text-primary" />
                      <span className="font-semibold">Facilitator Notes (Admin/Workshop Leader Only)</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="bg-muted/50 rounded-lg p-4 mt-2">
                      <ul className="space-y-2">
                        {scenarioFacilitatorNotes.map((note: string, idx: number) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <span className="text-primary mt-1">•</span>
                            <span>{note}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            )}

            <div className="flex justify-between">
              {currentScenario > 0 && (
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => setCurrentScenario(currentScenario - 1)}
                  data-testid="button-prev-scenario"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous Scenario
                </Button>
              )}
              {currentScenario < SCENARIOS.length - 1 ? (
                <Button
                  size="lg"
                  onClick={() => setCurrentScenario(currentScenario + 1)}
                  className="ml-auto"
                  data-testid="button-next-scenario"
                >
                  Next Scenario
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Link href="/workshop/action-plan" className="ml-auto">
                  <Button size="lg" data-testid="button-continue-action-plan">
                    Continue to Action Plan
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <Timer />

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Scenario Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {SCENARIOS.map((s, idx) => (
                  <button
                    key={s.id}
                    onClick={() => setCurrentScenario(idx)}
                    className={`w-full text-left p-3 rounded-lg border transition-all hover-elevate ${
                      idx === currentScenario
                        ? 'border-primary bg-primary/5'
                        : 'border-border'
                    }`}
                    data-testid={`button-scenario-${idx}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-foreground">
                        Scenario {idx + 1}
                      </span>
                      {responses[s.id].completed && (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                      {s.title}
                    </p>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
