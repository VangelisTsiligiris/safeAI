import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookOpen, AlertTriangle, Users, FileText, Download } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";

export default function WorkshopHome() {
  const [progress] = useState(0);

  const modules = [
    {
      id: 'fundamentals',
      title: 'AI Fundamentals for Fire Services',
      description: 'Learn about analytical AI, generative AI, and NFRS use cases',
      icon: BookOpen,
      href: '/workshop/fundamentals',
      duration: '15 min',
    },
    {
      id: 'risks',
      title: 'Risk & Ethics Framework',
      description: 'Understanding hallucination, bias, confidentiality, and public trust',
      icon: AlertTriangle,
      href: '/workshop/risks',
      duration: '15 min',
    },
    {
      id: 'scenarios',
      title: 'Interactive Scenarios',
      description: '4 realistic fire service scenarios for group discussion',
      icon: Users,
      href: '/workshop/scenarios',
      duration: '40 min',
    },
    {
      id: 'action-plan',
      title: 'Departmental Action Plan',
      description: 'Build your department\'s AI governance action plan',
      icon: FileText,
      href: '/workshop/action-plan',
      duration: '15 min',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b-4 border-workshop bg-workshop/5 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-xl font-bold text-workshop">Workshop Learning Platform</h1>
            <div className="w-32" /> {/* Spacer for balance */}
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-3">
            AI Governance Workshop for NFRS Employees
          </h2>
          <p className="text-lg text-muted-foreground mb-6">
            A comprehensive 90-minute workshop covering AI fundamentals, risks, policy compliance, 
            and practical governance approaches for all NFRS staff.
          </p>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Workshop Progress</span>
              <span>{progress}% Complete</span>
            </div>
            <Progress value={progress} className="h-2" data-testid="progress-workshop" />
          </div>
        </div>

        <div className="grid gap-6 mb-12">
          {modules.map((module, index) => (
            <Card key={module.id} className="border-l-4 border-l-workshop hover-elevate transition-all" data-testid={`card-module-${module.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-workshop/10 flex items-center justify-center flex-shrink-0">
                      <module.icon className="w-6 h-6 text-workshop" />
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-xl">
                          Module {index + 1}: {module.title}
                        </CardTitle>
                        <span className="text-xs text-muted-foreground bg-workshop/10 text-workshop px-2 py-1 rounded font-medium">
                          {module.duration}
                        </span>
                      </div>
                      <CardDescription className="text-base">
                        {module.description}
                      </CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Link href={module.href}>
                  <Button className="bg-workshop hover:bg-workshop/90 text-workshop-foreground" size="lg" data-testid={`button-start-${module.id}`}>
                    Start Module
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="border-2 border-workshop/20 bg-workshop/5">
          <CardHeader>
            <div className="flex items-start gap-3">
              <Download className="w-6 h-6 text-workshop mt-1" />
              <div>
                <CardTitle>Workshop Summary & Export</CardTitle>
                <CardDescription className="mt-2">
                  After completing all modules and scenarios, you can export a comprehensive 
                  workshop summary PDF including all group responses, action plans, and key takeaways.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Link href="/workshop/summary">
              <Button variant="outline" size="lg" data-testid="button-view-summary">
                View Summary & Export
              </Button>
            </Link>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
