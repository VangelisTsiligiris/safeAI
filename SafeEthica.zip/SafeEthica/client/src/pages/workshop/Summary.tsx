import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, CheckCircle2, FileText } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { generateWorkshopSummaryPDF } from "@/utils/pdfGenerator";

export default function Summary() {
  const handleExport = () => {
    generateWorkshopSummaryPDF();
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="Workshop Summary" />

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="mb-8">
          <Link href="/workshop">
            <Button variant="ghost" className="gap-2 mb-6" data-testid="button-back-workshop">
              <ArrowLeft className="w-4 h-4" />
              Back to Workshop
            </Button>
          </Link>

          <h1 className="text-3xl font-bold text-foreground mb-3">Workshop Summary & Outputs</h1>
          <p className="text-lg text-muted-foreground">
            Review your workshop progress and export a comprehensive summary for distribution to participants 
            and stakeholders.
          </p>
        </div>

        <div className="grid gap-6 mb-8">
          <Card className="border-l-4 border-l-green-500 bg-green-50/50">
            <CardHeader>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-600 mt-1" />
                <div>
                  <CardTitle>Module Completion Status</CardTitle>
                  <CardDescription className="mt-2">
                    Track which modules and exercises have been completed during this workshop session.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg bg-white border">
                  <span className="text-sm font-medium text-foreground">AI Fundamentals for Fire Services</span>
                  <CheckCircle2 className="w-5 h-5 text-green-600" data-testid="status-fundamentals" />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-white border">
                  <span className="text-sm font-medium text-foreground">Risk & Ethics Framework</span>
                  <CheckCircle2 className="w-5 h-5 text-green-600" data-testid="status-risks" />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-white border">
                  <span className="text-sm font-medium text-foreground">Interactive Scenarios (4 scenarios)</span>
                  <CheckCircle2 className="w-5 h-5 text-green-600" data-testid="status-scenarios" />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-white border">
                  <span className="text-sm font-medium text-foreground">Departmental Action Plans</span>
                  <CheckCircle2 className="w-5 h-5 text-green-600" data-testid="status-action-plan" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-start gap-3">
                <FileText className="w-6 h-6 text-primary mt-1" />
                <div>
                  <CardTitle>Scenario Responses Summary</CardTitle>
                  <CardDescription className="mt-2">
                    Aggregated group discussion notes and decisions from all scenario exercises.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h4 className="font-semibold text-foreground mb-2">Scenario 1: GenAI for Public Communications</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Group recommended: <span className="font-semibold text-amber-700">REFER</span> for assessment
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Key concerns: Accuracy during fast-moving incidents, need for Incident Commander approval, 
                    potential for hallucination causing public harm.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h4 className="font-semibold text-foreground mb-2">Scenario 2: AI-Assisted Safe & Well Prioritization</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Group recommended: <span className="font-semibold text-red-700">PROHIBIT</span> this use
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Key concerns: Personal data processing, algorithmic bias against vulnerable communities, 
                    GDPR Article 22 automated decision-making restrictions.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h4 className="font-semibold text-foreground mb-2">Scenario 3: Summarizing Operational Intelligence</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Group recommended: <span className="font-semibold text-green-700">PERMIT</span> with safeguards
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Safeguards: Use only Microsoft Copilot M365, anonymize all personal data first, 
                    human review mandatory, clear disclosure in final briefing.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-muted/50 border">
                  <h4 className="font-semibold text-foreground mb-2">Scenario 4: AI-Generated Training Content</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Group recommended: <span className="font-semibold text-amber-700">REFER</span> for assessment
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Key concerns: Life-critical accuracy requirements, potential copyright issues, 
                    need for expert technical validation.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Key Themes and Commitments</CardTitle>
              <CardDescription>
                Shared learnings and commitments from the workshop discussion.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>All departments recognize the need for human oversight and accountability in AI use</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>Personal data protection is a critical concern across all AI applications</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>Teams need practical guidance and training on POL 2114 implementation</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>Engagement with IGO, ICT Security, and OD&I is essential for most AI use cases</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-primary mt-1">•</span>
                  <span>Regular review and updating of AI governance approaches is necessary as technology evolves</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="border-2 border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle>Export Workshop Summary</CardTitle>
            <CardDescription>
              Generate a comprehensive PDF containing all module completions, scenario responses, 
              action plans, and key takeaways from this workshop session.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-white rounded-lg p-4 border">
              <h4 className="font-semibold text-foreground mb-2">PDF Summary Will Include:</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Workshop date and participant roles</li>
                <li>• Module completion status</li>
                <li>• All scenario responses and recommendations</li>
                <li>• Departmental action plans</li>
                <li>• Shared commitments and next steps</li>
                <li>• NFRS branding and POL 2114 references</li>
              </ul>
            </div>
            <Button
              size="lg"
              onClick={handleExport}
              className="w-full gap-2"
              data-testid="button-export-summary"
            >
              <Download className="w-4 h-4" />
              Export Workshop Summary as PDF
            </Button>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <Link href="/">
            <Button variant="outline" size="lg" data-testid="button-return-home">
              Return to Home
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
