import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Brain, BarChart3, MessageSquare, GitBranch, Eye, Download } from "lucide-react";
import { Header } from "@/components/shared/Header";
import { AI_FUNDAMENTALS } from "@/data/frameworkContent";
import { Badge } from "@/components/ui/badge";
import { exportFundamentals } from "@/lib/pdfExport";

const icons = {
  0: BarChart3,
  1: MessageSquare,
  2: GitBranch,
  3: Eye,
  4: Brain,
};

export default function AIFundamentals() {
  const handleExportPDF = () => {
    const content = AI_FUNDAMENTALS.subsections.map(subsection => ({
      title: subsection.heading,
      text: subsection.content,
      examples: subsection.examples,
    }));
    
    const keyTakeaways = [
      'AI is already being used across fire services for prediction, analysis, and content generation',
      'Analytical AI supports data-driven decision-making and resource optimization',
      'Generative AI can assist with content creation but requires careful human oversight',
      'All AI applications must align with POL 2114 and NFRS strategic goals',
    ];
    
    exportFundamentals(content, keyTakeaways);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header title="AI Fundamentals for Fire Services" subtitle="Module 1 of 4" />

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <Link href="/workshop">
            <Button variant="ghost" className="gap-2" data-testid="button-back-workshop">
              <ArrowLeft className="w-4 h-4" />
              Back to Workshop
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportPDF}
              className="gap-2"
              data-testid="button-export-pdf"
            >
              <Download className="w-4 h-4" />
              Export PDF
            </Button>
            <Badge variant="outline" className="text-sm">15 minutes</Badge>
          </div>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-3">{AI_FUNDAMENTALS.title}</h1>
          <p className="text-lg text-muted-foreground">
            Understanding the different types of AI and how they apply to fire and rescue services, 
            with real examples from NFRS operations.
          </p>
        </div>

        <div className="space-y-6 mb-12">
          {AI_FUNDAMENTALS.subsections.map((subsection, index) => {
            const Icon = icons[index as keyof typeof icons] || Brain;
            return (
              <Card key={subsection.heading} className="border-l-4 border-l-primary" data-testid={`card-subsection-${index}`}>
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{subsection.heading}</CardTitle>
                      <CardDescription className="text-base text-foreground leading-relaxed">
                        {subsection.content}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                {subsection.examples && subsection.examples.length > 0 && (
                  <CardContent>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm font-semibold text-foreground mb-3">Fire Service Examples:</p>
                      <ul className="space-y-2">
                        {subsection.examples.map((example, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <span className="text-primary mt-1">•</span>
                            <span>{example}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        <Card className="bg-primary/5 border-2 border-primary/20">
          <CardHeader>
            <CardTitle>Key Takeaways</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-start gap-2">
              <span className="text-primary mt-1">✓</span>
              <p className="text-sm text-foreground">AI is already being used across fire services for prediction, analysis, and content generation</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-primary mt-1">✓</span>
              <p className="text-sm text-foreground">Analytical AI supports data-driven decision-making and resource optimization</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-primary mt-1">✓</span>
              <p className="text-sm text-foreground">Generative AI can assist with content creation but requires careful human oversight</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-primary mt-1">✓</span>
              <p className="text-sm text-foreground">All AI applications must align with POL 2114 and NFRS strategic goals</p>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end mt-8">
          <Link href="/workshop/risks">
            <Button size="lg" className="gap-2" data-testid="button-next-module">
              Next Module: Risk & Ethics
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
