import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, BookOpen, CheckCircle, LogIn } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Landing() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Check if admin credentials
      if (username.toLowerCase() === "admin" && password === "admin2025") {
        const response = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ password }),
        });

        if (response.ok) {
          toast({
            title: "Success",
            description: "Admin access granted",
          });
          setLocation('/');
          window.location.reload();
        } else {
          toast({
            title: "Login Failed",
            description: "Invalid admin credentials",
            variant: "destructive",
          });
        }
      } else {
        // Staff login - redirect to OIDC
        window.location.href = "/api/login";
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="mb-6">
              <h1 className="text-4xl font-bold text-foreground mb-3">
                NFRS AI Toolkit
              </h1>
              <p className="text-xl text-muted-foreground">
                Nottinghamshire Fire & Rescue Service
              </p>
            </div>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto mb-8">
              Supporting safe, ethical, and responsible use of artificial intelligence 
              in line with POL 2114 and UK public sector values.
            </p>
            
            <Card className="max-w-md mx-auto mb-12">
              <CardHeader>
                <div className="flex justify-center mb-3">
                  <div className="bg-primary/10 p-3 rounded-full">
                    <LogIn className="w-8 h-8 text-primary" />
                  </div>
                </div>
                <CardTitle>Login to Access Toolkit</CardTitle>
                <CardDescription>
                  Admin users: enter "admin" and password. Staff members: use your email.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username / Email</Label>
                    <Input
                      id="username"
                      type="text"
                      placeholder="admin or your email"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      disabled={isLoading}
                      data-testid="input-username"
                      autoFocus
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      disabled={isLoading}
                      data-testid="input-password"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={!username || isLoading}
                    data-testid="button-login"
                  >
                    {isLoading ? "Logging in..." : "Login"}
                  </Button>
                </form>
                
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  <p>Admin access: username "admin" with password</p>
                  <p className="mt-1">Staff: use email (password optional)</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card data-testid="card-workshop">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <BookOpen className="h-8 w-8 text-primary" />
                  <CardTitle className="text-2xl">Workshop Learning Platform</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Interactive training for all NFRS employees
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>AI fundamentals and governance frameworks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Risk assessment and ethical considerations</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Interactive scenarios and action planning</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Departmental implementation roadmaps</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card data-testid="card-compliance">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Shield className="h-8 w-8 text-primary" />
                  <CardTitle className="text-2xl">Policy Compliance Checker</CardTitle>
                </div>
                <CardDescription className="text-base">
                  Quick assessment tool for all staff
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>12-question assessment aligned to POL 2114</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Instant decision: Permitted, Refer, or Prohibited</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>Tailored safeguards and guidance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span>PDF export with referral contacts</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground">
              This toolkit promotes transparency, accountability, and adherence to the NFRS Core Code of Ethics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
