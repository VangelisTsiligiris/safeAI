import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { WorkshopProvider } from "@/contexts/WorkshopContext";
import { useAuth } from "@/hooks/useAuth";
import { useAdmin } from "@/hooks/useAdmin";

// Pages
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import NotFound from "@/pages/not-found";

// Workshop pages
import WorkshopHome from "@/pages/workshop/WorkshopHome";
import AIFundamentals from "@/pages/workshop/AIFundamentals";
import RisksEthics from "@/pages/workshop/RisksEthics";
import Scenarios from "@/pages/workshop/Scenarios";
import ActionPlan from "@/pages/workshop/ActionPlan";
import Summary from "@/pages/workshop/Summary";

// Compliance pages
import ComplianceHome from "@/pages/compliance/ComplianceHome";
import TaskDescription from "@/pages/compliance/TaskDescription";
import Assessment from "@/pages/compliance/Assessment";
import Result from "@/pages/compliance/Result";

// Admin pages
import AdminPanel from "@/pages/admin/AdminPanel";
import AdminLogin from "@/pages/AdminLogin";

// Resources page
import Resources from "@/pages/Resources";

function Router() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { isAdmin, isLoading: adminLoading } = useAdmin();

  // Treat password-based admins as authenticated for routing purposes
  const isEffectivelyAuthenticated = isAuthenticated || isAdmin;
  const isLoading = authLoading || adminLoading;

  // Show landing page while loading or if not authenticated
  if (isLoading || !isEffectivelyAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/admin/login" component={AdminLogin} />
        <Route component={Landing} />
      </Switch>
    );
  }

  // Show authenticated routes
  return (
    <Switch>
      {/* Home */}
      <Route path="/" component={Home} />

      {/* Workshop Routes */}
      <Route path="/workshop" component={WorkshopHome} />
      <Route path="/workshop/fundamentals" component={AIFundamentals} />
      <Route path="/workshop/risks" component={RisksEthics} />
      <Route path="/workshop/scenarios" component={Scenarios} />
      <Route path="/workshop/action-plan" component={ActionPlan} />
      <Route path="/workshop/summary" component={Summary} />

      {/* Compliance Routes */}
      <Route path="/compliance" component={ComplianceHome} />
      <Route path="/compliance/task" component={TaskDescription} />
      <Route path="/compliance/assessment" component={Assessment} />
      <Route path="/compliance/result" component={Result} />

      {/* Admin Routes */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin" component={AdminPanel} />

      {/* Resources Route */}
      <Route path="/resources" component={Resources} />

      {/* 404 Fallback */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WorkshopProvider>
          <Toaster />
          <Router />
        </WorkshopProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
