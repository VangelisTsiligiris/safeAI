import { Shield } from "lucide-react";
import { Link } from "wouter";

interface HeaderProps {
  title: string;
  subtitle?: string;
  backHref?: string;
  backLabel?: string;
}

export function Header({ title, subtitle, backHref, backLabel }: HeaderProps) {
  return (
    <header className="border-b-4 border-nfrs-red bg-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer hover-elevate rounded-md px-2 py-1 -ml-2">
              <Shield className="w-8 h-8 text-nfrs-red" />
              <div>
                <div className="text-lg font-bold text-nfrs-dark-grey">NFRS AI Toolkit</div>
                <div className="text-xs text-muted-foreground">POL 2114</div>
              </div>
            </div>
          </Link>
          <div className="text-right">
            <h1 className="text-xl font-bold text-foreground">{title}</h1>
            {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
          </div>
        </div>
      </div>
    </header>
  );
}
