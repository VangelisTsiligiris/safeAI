import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, RotateCcw, Clock } from "lucide-react";

interface TimerProps {
  onTimeUsed?: (seconds: number) => void;
}

export function Timer({ onTimeUsed }: TimerProps) {
  const [selectedDuration, setSelectedDuration] = useState<number>(300); // 5 min default
  const [timeRemaining, setTimeRemaining] = useState<number>(300);
  const [isRunning, setIsRunning] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);

  const durations = [
    { label: '5 min', value: 300 },
    { label: '10 min', value: 600 },
    { label: '15 min', value: 900 },
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining((prev) => {
          const newTime = prev - 1;
          if (newTime === 0) {
            setIsRunning(false);
            if (onTimeUsed) {
              onTimeUsed(selectedDuration);
            }
          }
          return newTime;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeRemaining, selectedDuration, onTimeUsed]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setIsRunning(true);
    setHasStarted(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeRemaining(selectedDuration);
    setHasStarted(false);
  };

  const handleDurationChange = (duration: number) => {
    setSelectedDuration(duration);
    setTimeRemaining(duration);
    setIsRunning(false);
    setHasStarted(false);
  };

  const progress = ((selectedDuration - timeRemaining) / selectedDuration) * 100;

  return (
    <Card className="border-2 border-primary/20" data-testid="timer-card">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">Discussion Timer</h3>
        </div>

        <div className="flex gap-2 mb-6">
          {durations.map((duration) => (
            <Button
              key={duration.value}
              variant={selectedDuration === duration.value ? "default" : "outline"}
              size="sm"
              onClick={() => handleDurationChange(duration.value)}
              disabled={hasStarted}
              data-testid={`button-duration-${duration.value}`}
            >
              {duration.label}
            </Button>
          ))}
        </div>

        <div className="text-center mb-4">
          <div className="text-5xl font-bold text-primary mb-2" data-testid="text-time-remaining">
            {formatTime(timeRemaining)}
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-1000"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="flex gap-2 justify-center">
          {!isRunning ? (
            <Button onClick={handleStart} size="lg" className="gap-2" data-testid="button-start-timer">
              <Play className="w-4 h-4" />
              {hasStarted ? 'Resume' : 'Start'}
            </Button>
          ) : (
            <Button onClick={handlePause} size="lg" variant="outline" className="gap-2" data-testid="button-pause-timer">
              <Pause className="w-4 h-4" />
              Pause
            </Button>
          )}
          <Button onClick={handleReset} size="lg" variant="outline" className="gap-2" data-testid="button-reset-timer">
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
        </div>

        {timeRemaining === 0 && (
          <div className="mt-4 p-3 bg-primary/10 rounded-md text-center">
            <p className="text-sm font-medium text-primary">Time's up! Please wrap up your discussion.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
