import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useWorkshop } from '@/contexts/WorkshopContext';
import { useToast } from '@/hooks/use-toast';
import { Save, FolderOpen, Copy, Check } from 'lucide-react';

export function SessionControls() {
  const { sessionId, saveSession, loadSession } = useWorkshop();
  const { toast } = useToast();
  const [loadId, setLoadId] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const id = await saveSession();
      toast({
        title: "Session Saved",
        description: `Your workshop progress has been saved. Session ID: ${id.substring(0, 8)}...`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Could not save your session. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleLoad = async () => {
    if (!loadId.trim()) {
      toast({
        title: "Invalid Session ID",
        description: "Please enter a valid session ID.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      await loadSession(loadId.trim());
      toast({
        title: "Session Loaded",
        description: "Your workshop progress has been restored.",
      });
      setLoadId('');
    } catch (error) {
      toast({
        title: "Load Failed",
        description: "Could not load the session. Please check the session ID and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copySessionId = () => {
    if (sessionId) {
      navigator.clipboard.writeText(sessionId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Session ID Copied",
        description: "You can share this ID to resume your session later.",
      });
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Button
        variant="outline"
        size="sm"
        onClick={handleSave}
        disabled={isSaving}
        className="gap-2"
        data-testid="button-save-session"
      >
        <Save className="w-4 h-4" />
        {isSaving ? 'Saving...' : 'Save Progress'}
      </Button>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2" data-testid="button-load-session-trigger">
            <FolderOpen className="w-4 h-4" />
            Load Session
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Load Workshop Session</DialogTitle>
            <DialogDescription>
              Enter your session ID to restore your workshop progress.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="session-id">Session ID</Label>
              <Input
                id="session-id"
                placeholder="Enter session ID"
                value={loadId}
                onChange={(e) => setLoadId(e.target.value)}
                data-testid="input-session-id"
              />
            </div>
            <Button
              onClick={handleLoad}
              disabled={isLoading || !loadId.trim()}
              className="w-full"
              data-testid="button-load-session"
            >
              {isLoading ? 'Loading...' : 'Load Session'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {sessionId && (
        <Button
          variant="ghost"
          size="sm"
          onClick={copySessionId}
          className="gap-2"
          data-testid="button-copy-session-id"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              Copied
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              Copy ID
            </>
          )}
        </Button>
      )}
    </div>
  );
}
