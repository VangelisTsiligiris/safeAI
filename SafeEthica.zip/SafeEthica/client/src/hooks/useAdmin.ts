import { useQuery } from "@tanstack/react-query";

interface AdminCheckResponse {
  isAdmin: boolean;
}

interface AdminSessionResponse {
  isAdminPassword: boolean;
}

export function useAdmin() {
  // Check OIDC-based admin status
  const { data: oidcData, isLoading: oidcLoading } = useQuery<AdminCheckResponse>({
    queryKey: ['/api/admin/check'],
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  // Check password-based admin session
  const { data: sessionData, isLoading: sessionLoading } = useQuery<AdminSessionResponse>({
    queryKey: ['/api/admin/session'],
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  return {
    isAdmin: oidcData?.isAdmin === true || sessionData?.isAdminPassword === true,
    isLoading: oidcLoading || sessionLoading,
  };
}
