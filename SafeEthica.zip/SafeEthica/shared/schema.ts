import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  isAdmin: integer("is_admin").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Workshop Session Schema
export const workshopSessions = pgTable("workshop_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  department: text("department").notNull(),
  scenarioResponses: jsonb("scenario_responses"),
  actionPlan: jsonb("action_plan"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWorkshopSessionSchema = createInsertSchema(workshopSessions).omit({
  id: true,
  createdAt: true,
});

export type InsertWorkshopSession = z.infer<typeof insertWorkshopSessionSchema>;
export type WorkshopSession = typeof workshopSessions.$inferSelect;

// Compliance Assessment Schema
export const complianceAssessments = pgTable("compliance_assessments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  department: text("department").notNull(),
  taskDescription: text("task_description").notNull(),
  aiTool: text("ai_tool"),
  purpose: text("purpose"),
  responses: jsonb("responses").notNull(),
  outcome: text("outcome").notNull(),
  safeguards: jsonb("safeguards"),
  referrals: jsonb("referrals"),
  risks: jsonb("risks"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertComplianceAssessmentSchema = createInsertSchema(complianceAssessments).omit({
  id: true,
  createdAt: true,
});

export type InsertComplianceAssessment = z.infer<typeof insertComplianceAssessmentSchema>;
export type ComplianceAssessment = typeof complianceAssessments.$inferSelect;

// TypeScript interfaces for frontend use
export interface ScenarioResponse {
  scenarioId: string;
  risks: string;
  policyClauses: string;
  safeguards: string;
  recommendation: 'permit' | 'refer' | 'prohibit';
  notes: string;
  timerUsed: number;
}

export interface ActionPlan {
  department: string;
  aiUseCases: string;
  riskMitigation: string;
  trainingNeeds: string;
  governanceTouchpoints: string[];
  targetDates: string;
}

export interface AssessmentResponses {
  containsPersonalData: 'yes' | 'no' | 'unsure';
  containsSensitiveInfo: 'yes' | 'no' | 'unsure';
  exposesConfidential: 'yes' | 'no' | 'unsure';
  toolMeetsSecurity: 'yes' | 'no' | 'unsure';
  copyrightRisk: 'yes' | 'no' | 'unsure';
  willVerifyOutputs: 'yes' | 'no' | 'unsure';
  understandsAccountability: 'yes' | 'no' | 'unsure';
  reidentificationRisk: 'yes' | 'no' | 'unsure';
  couldCauseBias: 'yes' | 'no' | 'unsure';
  alignsWithEthics: 'yes' | 'no' | 'unsure';
  compliesLegal: 'yes' | 'no' | 'unsure';
  willDisclose: 'yes' | 'no' | 'unsure';
}

export interface ComplianceDecision {
  outcome: 'PERMITTED' | 'REFER' | 'PROHIBITED';
  risks: Risk[];
  safeguards: string[];
  referrals: Referral[];
  policyClauses: string[];
  explanation: string;
}

export interface Risk {
  category: string;
  clause: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  description: string;
}

export interface Referral {
  contact: string;
  role: string;
  reason: string;
  email?: string;
  phone?: string;
}
