-- NFRS AI Toolkit - Admin Setup Script
-- This script grants admin access to a specific user

-- IMPORTANT: First, log in to the application to create your user account in the database

-- HOW TO RUN THIS SCRIPT:
-- 
-- Option 1: Replit Database Tools (Development)
--   1. Click "Tools" → "Database" in Replit sidebar
--   2. Click "Query" to open SQL console
--   3. Copy and paste the commands below
--
-- Option 2: psql command line (Development/Production)
--   1. Open terminal
--   2. Run: psql $DATABASE_URL
--   3. Copy and paste the commands below
--
-- Option 3: Neon Dashboard (Production)
--   1. Access your Neon database dashboard
--   2. Navigate to SQL Editor
--   3. Copy and paste the commands below

-- STEP 1: Find your user ID
SELECT id, email FROM users;

-- STEP 2: Grant admin access (replace YOUR_USER_ID_HERE with actual user ID)
-- Uncomment the line below and replace YOUR_USER_ID_HERE:
-- UPDATE users SET is_admin = 1 WHERE id = 'YOUR_USER_ID_HERE';

-- Example: If your user ID is '123e4567-e89b-12d3-a456-426614174000':
-- UPDATE users SET is_admin = 1 WHERE id = '123e4567-e89b-12d3-a456-426614174000';

-- STEP 3: Verify admin status
SELECT id, email, is_admin FROM users;

-- To revoke admin access later:
-- UPDATE users SET is_admin = 0 WHERE id = 'YOUR_USER_ID_HERE';

-- SECURITY NOTE: 
-- - Only run this through secure database access (database tools, psql, or Neon dashboard)
-- - Never expose admin promotion capability through public APIs
-- - This manual process prevents unauthorized privilege escalation
