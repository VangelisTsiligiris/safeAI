# NFRS AI Toolkit

## Overview

The NFRS AI Toolkit is a full-stack web application designed for Nottinghamshire Fire & Rescue Service to support safe, ethical, and responsible use of artificial intelligence. The application serves two primary functions:

1. **Workshop Learning Platform**: An interactive educational experience for all NFRS employees providing training on AI governance, risks, and policy compliance aligned with POL 2114 (NFRS Artificial Intelligence Policy)

2. **AI Policy Compliance Checker**: A standalone assessment tool enabling all NFRS employees to evaluate whether their proposed AI tasks comply with organizational policy before implementation

The toolkit emphasizes transparency, accountability, and adherence to UK public sector values, incorporating NFRS Core Code of Ethics and the Annual Delivery Plan 2025-26 strategic goals.

## Recent Changes

**November 8, 2025 - Final Updates**
- **Unified Login System**: Replaced dual login buttons with single login form on landing page
  - Admin login: username "admin" with password "admin2025"
  - Staff login: any other username/email redirects to OIDC authentication
  - Simplified user experience with clear credential instructions
  - Maintains all existing security features (rate limiting, session timeout, audit logging)
- **Complete PDF Export**: Enhanced workshop module PDF exports to include ALL content
  - PDF now includes examples from each subsection with bullet formatting
  - Key takeaways section added to both AI Fundamentals and Risk & Ethics modules
  - Comprehensive content export matching what users see on screen
  - Proper formatting with NFRS branding and policy references
- **End-to-end Testing**: Validated complete user journey from login through workshop to admin panel
  - All authentication flows working correctly
  - PDF exports generating complete documents
  - Admin resource management fully functional

**November 8, 2025 - Earlier Updates**
- **Enhanced Landing Page**: Added clear dual login options for "Staff Member" and "Admin/Facilitator" with distinct cards explaining access levels
- **Updated Workshop Wording**: Changed all "senior leadership" references to "all NFRS employees" to make workshop relevant to entire organization
- **PDF Export Functionality**: Added PDF export buttons to all workshop modules:
  - AI Fundamentals module: Export educational content as PDF
  - Risk & Ethics module: Export framework content as PDF
  - Interactive Scenarios module: Export scenario descriptions and group responses as PDF
  - Action Plan module: Already had PDF export (unchanged)
  - Summary page: Already had comprehensive workshop summary PDF export (unchanged)
  - All PDFs include NFRS branding, proper formatting, and policy references
- **Admin Password Authentication System**: Implemented secure password-based admin login alongside OIDC:
  - Standard password "admin2025" for direct admin access without OIDC setup
  - Dual authentication: OIDC for staff (with database admin flag) OR password-based for direct admin access
  - IP-based rate limiting (5 attempts per 15 minutes) with automatic lockout
  - Session regeneration on successful login to prevent session fixation attacks
  - 1-hour session timeout with automatic expiry validation
  - Dedicated logout endpoint (POST /api/admin/logout) for password-based sessions
  - Session expiry checks in both middleware and session validation endpoint
- **Resource File Management**: Added comprehensive admin panel capabilities:
  - File editing/renaming functionality with strict validation
  - Path traversal protection using path.normalize() and directory boundary checks
  - Filename validation regex: /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,127}$/
  - Extension whitelist: .pdf, .docx, .xlsx, .xls, .doc, .txt, .csv
  - Duplicate filename prevention
  - Audit logging for all file operations (FILE_UPLOAD, FILE_RENAME, FILE_DELETE)
- **Compliance Checker UI Improvements**: Enhanced visibility and accessibility:
  - Numbered section badges with colored backgrounds for visual hierarchy
  - Individual Card components for each question with distinct borders
  - Improved spacing between sections (space-y-8) and questions (space-y-5)
  - Hover effects on question cards for better interactivity
  - Visual indentation to group questions under section headers

**November 7, 2025**
- Migrated from in-memory storage to PostgreSQL database with full persistence
- Implemented PgStorage class using Drizzle ORM with neon-http adapter
- Fixed compliance assessment backend save functionality with proper JSON parsing
- Created WorkshopContext infrastructure for session state management
- Added SessionControls component for save/load functionality
- Database validated and tested - both compliance assessments and workshop sessions persist correctly
- **Added admin panel with secure file upload functionality:**
  - Admin role system with `isAdmin` field in users table
  - `requireAdmin` middleware for route protection
  - Secure file upload with MIME type validation, size limits (10MB), and UUID filenames
  - Files stored outside web root in `admin_uploads` directory
  - Audit logging to console and `admin_audit.log` file
  - Admin panel UI for resource upload/management
  - Admin link shown only to admin users on Home page
  - **Security enhancement**: Facilitator notes moved to admin-only backend endpoint (no longer in client bundle)

### Admin Access

The application supports two methods of admin authentication:

**Method 1: Password-Based Admin Login (Quick Access)**
- Navigate to Landing page and click "Admin Password Login"
- Enter password: `admin2025`
- Security features:
  - Rate limiting: 5 login attempts per 15 minutes (IP-based)
  - Session timeout: 1 hour automatic expiry
  - Session regeneration on login prevents session fixation
  - Dedicated logout endpoint for secure session cleanup
- Use cases: Quick admin access, demonstration environments, initial setup

**Method 2: OIDC-Based Admin Access (Database-Managed)**

To grant admin access to a specific user (requires database access):

**Prerequisites:**
- Log in to the application first to create your user account via Replit Auth

**Option 1: Using Replit Database Tools (Development)**

1. Click on "Tools" in the left sidebar, then select "Database"
2. Click "Query" to open the SQL console
3. Find your user ID:
   ```sql
   SELECT id, email FROM users;
   ```
4. Grant admin access (replace `YOUR_USER_ID_HERE` with your actual ID):
   ```sql
   UPDATE users SET is_admin = 1 WHERE id = 'YOUR_USER_ID_HERE';
   ```
5. Verify admin status:
   ```sql
   SELECT id, email, is_admin FROM users;
   ```

**Option 2: Using psql (Production/Development)**

1. Open a terminal/shell
2. Connect to the database using the DATABASE_URL environment variable:
   ```bash
   psql $DATABASE_URL
   ```
3. Run the SQL commands above to grant admin access

**Option 3: Using Neon Dashboard (Production)**

1. Access your Neon database dashboard
2. Navigate to the SQL Editor
3. Run the SQL commands above to grant admin access

**Security Note:** 
- Admin promotion for OIDC users must be done manually through database access
- There is intentionally no API endpoint for promotion to prevent unauthorized access elevation
- Password-based admin access (`admin2025`) should be changed in production environments
- Rate limiting and session timeouts apply to both authentication methods
- All admin actions are logged with user/session identifiers for audit trails

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: React with TypeScript, using Vite as the build tool and bundler. The application follows a single-page application (SPA) pattern with client-side routing via Wouter.

**UI Framework**: Implements shadcn/ui component library (New York style variant) built on Radix UI primitives with Tailwind CSS for styling. The design system follows GOV.UK-inspired conventions prioritizing clarity, accessibility, and professional aesthetics over decorative elements.

**Design System**: Custom color palette centered on NFRS brand red (#C8102E) with semantic color tokens for compliance outcomes (Success Green for "PERMITTED", Warning Amber for "REFER BEFORE USE", Prohibition Red for "PROHIBITED"). Typography uses Inter/Open Sans with a structured type scale. Layout follows consistent spacing primitives and responsive grid patterns.

**State Management**: TanStack Query (React Query) manages server state with configured query client. Form state handled through React Hook Form with Zod schema validation via @hookform/resolvers.

**Routing Structure**: 
- Home page serves as entry point with navigation to Workshop and Compliance modes
- Workshop flow: Home → Fundamentals → Risks/Ethics → Scenarios → Action Plan → Summary
- Compliance flow: Home → Task Description → Assessment → Result

### Backend Architecture

**Runtime**: Node.js with Express.js framework providing REST API endpoints.

**API Design**: RESTful endpoints organized by feature domain:
- `/api/workshop/*` - Educational content delivery and session management
- `/api/compliance/*` - Assessment creation and retrieval
- Static content endpoints serve framework content, scenarios, and policy excerpts

**Data Access Layer**: Storage interface abstraction (IStorage) with in-memory implementation (MemStorage). The architecture supports future database integration through the interface pattern without requiring API changes.

**Session Management**: Workshop sessions and compliance assessments are created with unique identifiers (UUIDs) and stored with metadata including department, responses, outcomes, and timestamps.

**Business Logic**: Policy compliance assessment logic (`policyLogic.ts`) implements scoring algorithm evaluating responses against POL 2114 criteria. Produces structured decisions with risk categorization, severity levels, safeguards, and referral recommendations to appropriate NFRS contacts (Information Governance Officer, ICT Security Manager, Organisational Development and Inclusion Manager).

### Data Storage Solutions

**Current Implementation**: PostgreSQL database with Drizzle ORM providing full persistence for workshop sessions and compliance assessments.

**Storage Architecture**: 
- `PgStorage` class implements IStorage interface with full CRUD operations
- Uses Drizzle ORM with neon-http adapter for serverless-compatible HTTP connections
- Database initialization includes environment variable validation with descriptive error messages
- All queries use type-safe Drizzle ORM methods (select, insert, update) with `.returning()` for immediate data retrieval

**Schema Definition**: Drizzle ORM schemas define PostgreSQL table structures with proper typing and validation:
- `workshopSessions`: Stores department, scenario responses (JSONB), action plans (JSONB), and timestamps
- `complianceAssessments`: Stores department, task details, responses (JSONB), outcome, safeguards, referrals, risks (all JSONB for structured data), and timestamps

**Database Configuration**: PostgreSQL via Neon database service. Connection managed through DATABASE_URL environment variable with HTTP adapter (`drizzle-orm/neon-http`) for optimal serverless performance. Schema synchronized via `npm run db:push` command.

**Design Rationale**: JSONB columns chosen for flexible storage of complex nested objects (scenario responses, risk arrays, referral structures) while maintaining queryability. UUID primary keys (varchar with `gen_random_uuid()`) ensure distributed system compatibility and prevent ID collisions.

### External Dependencies

**UI Component Libraries**:
- Radix UI primitives (@radix-ui/react-*) for accessible, unstyled components
- shadcn/ui configuration for pre-styled component variants
- Tailwind CSS for utility-first styling with custom NFRS theme

**Form & Validation**:
- React Hook Form for performant form state management
- Zod for runtime schema validation and type inference
- drizzle-zod for generating Zod schemas from database schema definitions

**Data Fetching**:
- TanStack Query for server state management, caching, and synchronization
- Custom apiRequest wrapper for consistent error handling

**Database**:
- Drizzle ORM for type-safe database queries and migrations
- @neondatabase/serverless for PostgreSQL connection (serverless-compatible)
- connect-pg-simple for session store (configured but not actively used with current in-memory storage)

**Development Tools**:
- Replit-specific plugins for development banner, error overlay, and cartographer integration
- tsx for TypeScript execution in development
- esbuild for production server bundling

**Utility Libraries**:
- date-fns for date manipulation and formatting
- clsx and tailwind-merge (via cn utility) for conditional className composition
- class-variance-authority for component variant management
- nanoid for generating unique identifiers

**PDF Generation**:
- jsPDF for generating compliance assessment result PDFs with NFRS branding

**Additional UI Enhancements**:
- embla-carousel-react for carousel/slider components
- cmdk for command palette functionality
- lucide-react for icon system